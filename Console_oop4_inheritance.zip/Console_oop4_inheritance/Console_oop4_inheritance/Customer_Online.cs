﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop4_inheritance
{
    class Customer_Online:Customer
    {
        private string PaymentType;
        private string DeliveryAddress;
        public Customer_Online(string CustomerEmailID,string CustomerName,string PaymentType,string DeliveryAddress)
            :base(CustomerEmailID,CustomerName)
        {
            this.PaymentType = PaymentType;
            this.DeliveryAddress = DeliveryAddress;
            Console.WriteLine("customer constructor");

        }
        public string PPaymentType
        {
            get
            {
                return this.PaymentType;
            }
        }
        public string PDeliveryAddress
        {
            get
            {
                return this.DeliveryAddress;
            }
        }

    }
}
