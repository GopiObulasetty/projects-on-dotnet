﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop4_inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the email");
            string Email = Console.ReadLine();
            Console.WriteLine("enter the name");
            string Name = Console.ReadLine();

          
            Console.WriteLine("enter customer type");
            string type = Console.ReadLine();
            if(type=="Online")
            {
                Console.WriteLine("enter the PaymentTypw");
                string PaymentType = Console.ReadLine();
                Console.WriteLine("enter Delivery addess");
                string DeliveryAddress = Console.ReadLine();
                Customer_Online obj_online = new Customer_Online(Email, Name, PaymentType, DeliveryAddress);
                Console.WriteLine(obj_online.PCustomerEmailID + "" + obj_online.PCustomerName
                +""+obj_online.PPaymentType + "" + obj_online.PDeliveryAddress);
            }
            else
            {
                Customer obj = new Customer(Email, Name);
                Console.WriteLine(obj.PCustomerEmailID + "" + obj.PCustomerName);

            }

            Console.ReadLine();

        }
    }
}
