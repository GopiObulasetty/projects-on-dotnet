﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop4_inheritance
{
    class Customer
    {
        private string CustomerEmailID;
        private string CustomerName;

        public Customer(string CustomerEmailID, string CustomerName)
        {
            this.CustomerEmailID = CustomerEmailID;
            this.CustomerName = CustomerName;

        }
        public string PCustomerEmailID
        {
            get
            {
                return this.CustomerEmailID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
    }
}
