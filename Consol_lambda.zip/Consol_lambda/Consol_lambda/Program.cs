﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consol_lambda
{
    class Program
    {
        static void Main(string[] args)
        {

            List<Customer> custlist = new List<Customer>();
            custlist.Add(new Customer { CustomerID = 1, CustomerAge = 25, CustomerCity = "BGL", CustomerName = "ABC" });
            custlist.Add(new Customer { CustomerID = 2, CustomerAge = 30, CustomerName = "gopi", CustomerCity = "hyd" });
            custlist.Add(new Customer { CustomerID = 3, CustomerAge = 20, CustomerName = "vinay", CustomerCity = "chenni" });
            custlist.Add(new Customer { CustomerID = 4, CustomerAge = 20, CustomerName = "ram", CustomerCity = "BGL" });
            custlist.Add(new Customer { CustomerID = 5, CustomerAge = 23, CustomerName = "sriker", CustomerCity = "hyd" });

            List<Order> ordlist = new List<Order>();
            ordlist.Add(new Order { OrderID = 1001, CustomerID = 1, ItemName = "onepluse", ItemPrice = 25000 });
            ordlist.Add(new Order { OrderID = 1002, CustomerID = 1, ItemName = "tv", ItemPrice = 1500 });
            ordlist.Add(new Order { OrderID = 1003, CustomerID = 2, ItemName = "onepluse", ItemPrice = 30000 });
            ordlist.Add(new Order { OrderID = 1004, CustomerID = 3, ItemName = "laptop", ItemPrice = 55000 });

            var data = custlist.Where((c) => c.CustomerCity == "hyd");

            foreach(var x in data)
            {
                Console.WriteLine(x.CustomerID + " " + x.CustomerName);
            }

            var count = custlist.Count((c) => c.CustomerCity == "hyd");
            Console.WriteLine(count);

            var obj = custlist.FirstOrDefault((c) => c.CustomerID == 1);
            if(obj!=null)
            {
                Console.WriteLine(obj.CustomerID + " " + obj.CustomerName);

            }
            else
            {
                Console.WriteLine("not found");
            }


            
            var status = custlist.Exists((c) => c.CustomerID == 1);
            Console.WriteLine(status);


            var dataprojection=custlist.Where((c) => c.CustomerCity == "hyd").Select((s) => new { CID = s.CustomerID, CName = s.CustomerName });
            foreach(var d in dataprojection)
            {
                Console.WriteLine(d.CID + "" + d.CName);
            }

            var dataorderby = custlist.Where((c) => c.CustomerAge > 20).OrderBy((o) => o.CustomerName).ThenByDescending((o1) => o1.CustomerCity);

            foreach(var d in dataorderby)
            {
                Console.WriteLine(d.CustomerID + " " + d.CustomerName + " " + d.CustomerCity);
            }
            var groupdata = custlist.GroupBy((g) => g.CustomerCity).
                Select((s) => new
                {
                    city = s.Key,
                    count = s.Count(),
                    avg = s.Average((a) => a.CustomerAge)

                });
            foreach(var x in groupdata)
            {
                Console.WriteLine(x.city + " " + x.count + "" + x.avg);

            }

            //jpining

            var joindata = custlist.Join(ordlist,
                (c) => c.CustomerID,
                (o) => o.CustomerID,
                (c, o) => new
                {
                    CID = c.CustomerID,
                    CName = c.CustomerName,
                    OID = o.OrderID,
                    IName = o.ItemName,
                    IPrice = o.ItemPrice
                });
            foreach(var j in joindata)
            {
                Console.WriteLine(j.CID + " " + j.CName + " " + j.OID + " " + j.IName + " " + j.IPrice);
            }






            Console.ReadLine();
        }
    }
}
