﻿namespace Win_Thread_assingment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_substarct = new System.Windows.Forms.Button();
            this.lbl_number1 = new System.Windows.Forms.Label();
            this.lbl_number2 = new System.Windows.Forms.Label();
            this.txt_number1 = new System.Windows.Forms.TextBox();
            this.txt_number2 = new System.Windows.Forms.TextBox();
            this.lst_result = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(89, 202);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 0;
            this.btn_add.Text = "+";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_substarct
            // 
            this.btn_substarct.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_substarct.Location = new System.Drawing.Point(216, 188);
            this.btn_substarct.Name = "btn_substarct";
            this.btn_substarct.Size = new System.Drawing.Size(75, 37);
            this.btn_substarct.TabIndex = 1;
            this.btn_substarct.Text = "-";
            this.btn_substarct.UseVisualStyleBackColor = true;
            this.btn_substarct.Click += new System.EventHandler(this.btn_substarct_Click);
            // 
            // lbl_number1
            // 
            this.lbl_number1.AutoSize = true;
            this.lbl_number1.Location = new System.Drawing.Point(69, 57);
            this.lbl_number1.Name = "lbl_number1";
            this.lbl_number1.Size = new System.Drawing.Size(53, 13);
            this.lbl_number1.TabIndex = 2;
            this.lbl_number1.Text = "Number 1";
            // 
            // lbl_number2
            // 
            this.lbl_number2.AutoSize = true;
            this.lbl_number2.Location = new System.Drawing.Point(69, 123);
            this.lbl_number2.Name = "lbl_number2";
            this.lbl_number2.Size = new System.Drawing.Size(53, 13);
            this.lbl_number2.TabIndex = 3;
            this.lbl_number2.Text = "Number 2";
            // 
            // txt_number1
            // 
            this.txt_number1.Location = new System.Drawing.Point(161, 57);
            this.txt_number1.Name = "txt_number1";
            this.txt_number1.Size = new System.Drawing.Size(100, 20);
            this.txt_number1.TabIndex = 4;
            // 
            // txt_number2
            // 
            this.txt_number2.Location = new System.Drawing.Point(165, 118);
            this.txt_number2.Name = "txt_number2";
            this.txt_number2.Size = new System.Drawing.Size(100, 20);
            this.txt_number2.TabIndex = 5;
            // 
            // lst_result
            // 
            this.lst_result.FormattingEnabled = true;
            this.lst_result.Location = new System.Drawing.Point(320, 54);
            this.lst_result.Name = "lst_result";
            this.lst_result.Size = new System.Drawing.Size(134, 147);
            this.lst_result.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 367);
            this.Controls.Add(this.lst_result);
            this.Controls.Add(this.txt_number2);
            this.Controls.Add(this.txt_number1);
            this.Controls.Add(this.lbl_number2);
            this.Controls.Add(this.lbl_number1);
            this.Controls.Add(this.btn_substarct);
            this.Controls.Add(this.btn_add);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_substarct;
        private System.Windows.Forms.Label lbl_number1;
        private System.Windows.Forms.Label lbl_number2;
        private System.Windows.Forms.TextBox txt_number1;
        private System.Windows.Forms.TextBox txt_number2;
        private System.Windows.Forms.ListBox lst_result;
    }
}

