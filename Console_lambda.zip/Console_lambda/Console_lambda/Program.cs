﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_lambda
{
    class Program
    {
        static void Main(string[] args)
        {
            List<employee> emplist = new List<employee>();
            emplist.Add(new employee { EmployeeID = 1001, EmployeeName = "gopi", EmployeeSalary = 30000, EmployeeExp = 8, EmployeeCity = "tenali" });
            emplist.Add(new employee { EmployeeID = 1002, EmployeeName = "vinay", EmployeeSalary = 50000, EmployeeExp = 4, EmployeeCity = "vjwd" });
            emplist.Add(new employee { EmployeeID = 1003, EmployeeName = "rahul", EmployeeSalary = 70000, EmployeeExp = 6, EmployeeCity = "hyd" });
            emplist.Add(new employee { EmployeeID = 1004, EmployeeName = "ram", EmployeeSalary = 65000, EmployeeExp = 5, EmployeeCity = "tenali" });
            emplist.Add(new employee { EmployeeID = 1005, EmployeeName = "sriker", EmployeeSalary = 90000, EmployeeExp = 2, EmployeeCity = "hyd" });


            List<employeeLeave> levlist = new List<employeeLeave>();
            levlist.Add(new employeeLeave { LeaveID = 1, LeaveType = "sick", Reason = "feaver", EmployeeID = 1001 });
            levlist.Add(new employeeLeave { LeaveID = 2, LeaveType = "vecation", Reason = "turupati", EmployeeID = 1002 });
            levlist.Add(new employeeLeave { LeaveID = 3, LeaveType = "casual", Reason = "home", EmployeeID = 1003 });
            levlist.Add(new employeeLeave { LeaveID = 4, LeaveType = "sick", Reason = "feaver", EmployeeID = 1004 });
            levlist.Add(new employeeLeave { LeaveID = 5, LeaveType = "casual", Reason = "relitivs home", EmployeeID = 1005 });




            //LINQ
            //1
            var data = from c in emplist
                       where c.EmployeeExp > 5
                       select new { EmpID = c.EmployeeID, name = c.EmployeeName, salary = c.EmployeeSalary, city = c.EmployeeCity };
            foreach(var b in data)
            {
                Console.WriteLine(b.EmpID + " " + b.name + " " + b.salary + " " +b. city);
            }
            //2
            var sal = from c in emplist
                      where c.EmployeeSalary > 50000
                      select new { empid = c.EmployeeID, name = c.EmployeeName };
            foreach(var j in sal)
            {
                Console.WriteLine(j.empid + " " + j.name);
            }
            //3
            string city = "tenali";
            var vil = from c in emplist
                       where c.EmployeeCity == city
                       select new { empid = c.EmployeeID, name = c.EmployeeName };

            foreach(var t in vil)
            {
                Console.WriteLine(t.empid + " " + t.name);
            }
            //4
            var ename = from c in emplist
                        where c.EmployeeName.StartsWith("r")
                        select c ;
            foreach(var k in ename)
            {
                Console.WriteLine(k.EmployeeName + " " + k.EmployeeID);
            }
            //lambdas

            var lex = emplist.Where((c) => c.EmployeeExp > 5).Select((c) => new { id = c.EmployeeID, name = c.EmployeeName });
            foreach(var a in lex)
            {
                Console.WriteLine(a.id + " " + a.name);
            }

            var lsal = emplist.Where((c) => c.EmployeeSalary > 50000).Select((g) => new { id = g.EmployeeID, name = g.EmployeeName });
            foreach(var d in lsal )
            {
                Console.WriteLine(d.id + " " + d.name);

            }

            var lcity = emplist.Where((c) => c.EmployeeCity == "tenali").Select((c) => new { id = c.EmployeeID, name = c.EmployeeName, });
            foreach(var l in lcity)
            {
                Console.WriteLine(l.id + " " + l.name);

            }

            var lsn = emplist.Where((c) => c.EmployeeName.StartsWith("r"));
            foreach(var v in lsn)
                {
                Console.WriteLine(v.EmployeeID + " " + v.EmployeeName);

            }

            var joindata = emplist.Join(levlist,
                (e) => e.EmployeeID,
                (l) => l.EmployeeID,
                (e, l) => new { empid = e.EmployeeID, name = e.EmployeeName, lid = l.LeaveID, res = l.Reason });
            foreach(var x in joindata)
                {
                Console.WriteLine(x.empid + " " +x.name+" "+x.lid+"  "+x.res);

            }









            Console.ReadLine();
        }
    }
}
