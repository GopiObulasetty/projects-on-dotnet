﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Company_Employee
{
    interface IAccountEmp
    {
        int GetEmployeeID();

        int GetEmployeeSalary();

        int GetEmployeeAccountNumber();
    }
}
