﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Company_Employee
{
    class Account
    {
        public void GetEmployee(IAccountEmp e)
        {
            int EmpSal = e.GetEmployeeSalary();
            Console.WriteLine("emp sal" + EmpSal);
            int AccNo = e.GetEmployeeAccountNumber();
            Console.WriteLine("Account number is" + AccNo);
            int EmpID = e.GetEmployeeID();
            Console.WriteLine("employee id" + EmpID);
        }
    }
}
