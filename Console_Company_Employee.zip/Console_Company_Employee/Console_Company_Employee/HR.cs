﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Company_Employee
{
    class HR
    {
     public void GetEmployee(IHREEmp e)
        {
            string Add=e.GetEmployeeAddress();
            Console.WriteLine("address" + Add);
            int EmpSal = e.GetEmployeeSalary();
            Console.WriteLine("salary" + EmpSal);
            int EmpID = e.GetEmployeeID();
            Console.WriteLine("employee " + EmpID);     
            
        }
    }
}
