﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Company_Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee(1001, "gopi", "tenali", "andhrapradesh", "bhel",2, 67893736," hdfc", 23);

            HR h = new HR();

            Account a = new Account();
            Manager m = new Manager();


            h.GetEmployee(emp);
            a.GetEmployee(emp);
            m.GetEmployee(emp);

            Console.ReadLine();
        }
    }
}
