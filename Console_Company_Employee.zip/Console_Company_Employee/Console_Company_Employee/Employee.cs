﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Company_Employee
{
    class Employee:IAccountEmp,IHREEmp,IMangerEmp
    {
        private int EmployeeID;
        private string EmployeeName;
        private string EmployeeCity;
        private string EmployeeAddress;
        private string EmployeeProjectDetails;
        private int EmployeeExp;
        private int EmployeeAccountNumber;
        private string EmployeeBankName;
        private int EmployeeAge;

        public Employee(int EmployeeID, string EmployeeName, string EmployeeCity, 
            string EmployeeAddress,string EmployeeProjectDetails, int EmployeeExp, int EmployeeAccountNumber,
            string EmployeeBankName, int EmployeeAge)
        {
            this.EmployeeID = EmployeeID;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
            this.EmployeeAddress = EmployeeAddress;
            this.EmployeeProjectDetails = EmployeeProjectDetails;
            this.EmployeeExp = EmployeeExp;
            this.EmployeeAccountNumber = EmployeeAccountNumber;
            this.EmployeeBankName = EmployeeBankName;
            this.EmployeeAge = EmployeeAge;

        }

        public int GetEmployeeID()
        {
           return this.EmployeeID;
        }

        public int GetEmployeeSalary()
        {
            return 30000;
        }

        public int GetEmployeeAccountNumber()
        {
           return  this.EmployeeAccountNumber;
        }

        public string GetEmployeeAddress()
        {
            return this.EmployeeAddress;
        }

        public int GetEmployeeExp()
        {
            return this.EmployeeExp;
        }

        public string GetEmployeeProjectDetail()
        {
            return this.EmployeeProjectDetails;
        }

        
        
    }
}
