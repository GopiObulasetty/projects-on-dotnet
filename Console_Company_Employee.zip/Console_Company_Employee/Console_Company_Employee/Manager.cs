﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Company_Employee
{
    class Manager
    {
        public void GetEmployee(IMangerEmp e)
        {
            int EmpID = e.GetEmployeeID();
            Console.WriteLine("employee id" + EmpID);
            int EmpExp = e.GetEmployeeExp();
            Console.WriteLine("employee experience" + EmpExp);
            string EmpPD = e.GetEmployeeProjectDetail();
            Console.WriteLine("employee project details" + EmpPD);
        }
    }
}
