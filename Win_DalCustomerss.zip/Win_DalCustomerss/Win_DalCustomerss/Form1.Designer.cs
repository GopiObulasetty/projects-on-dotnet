﻿namespace Win_DalCustomerss
{
    partial class form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_customerpassword = new System.Windows.Forms.Label();
            this.lbl_customercity = new System.Windows.Forms.Label();
            this.lbl_customeraddress = new System.Windows.Forms.Label();
            this.lbl_customermobilenumber = new System.Windows.Forms.Label();
            this.lbl_customeremailid = new System.Windows.Forms.Label();
            this.txt_Customerpassword = new System.Windows.Forms.TextBox();
            this.txt_customeradress = new System.Windows.Forms.TextBox();
            this.txt_customermobilenumber = new System.Windows.Forms.TextBox();
            this.txt_customeremailid = new System.Windows.Forms.TextBox();
            this.btn_newcustomer = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.txt_customercity = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Location = new System.Drawing.Point(34, 60);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(82, 13);
            this.lbl_customername.TabIndex = 0;
            this.lbl_customername.Text = "Customer Name";
            // 
            // lbl_customerpassword
            // 
            this.lbl_customerpassword.AutoSize = true;
            this.lbl_customerpassword.Location = new System.Drawing.Point(34, 95);
            this.lbl_customerpassword.Name = "lbl_customerpassword";
            this.lbl_customerpassword.Size = new System.Drawing.Size(103, 13);
            this.lbl_customerpassword.TabIndex = 1;
            this.lbl_customerpassword.Text = "Customer Password:";
            // 
            // lbl_customercity
            // 
            this.lbl_customercity.AutoSize = true;
            this.lbl_customercity.Location = new System.Drawing.Point(34, 135);
            this.lbl_customercity.Name = "lbl_customercity";
            this.lbl_customercity.Size = new System.Drawing.Size(71, 13);
            this.lbl_customercity.TabIndex = 2;
            this.lbl_customercity.Text = "Customer City";
            // 
            // lbl_customeraddress
            // 
            this.lbl_customeraddress.AutoSize = true;
            this.lbl_customeraddress.Location = new System.Drawing.Point(34, 174);
            this.lbl_customeraddress.Name = "lbl_customeraddress";
            this.lbl_customeraddress.Size = new System.Drawing.Size(92, 13);
            this.lbl_customeraddress.TabIndex = 3;
            this.lbl_customeraddress.Text = "Customer Address";
            // 
            // lbl_customermobilenumber
            // 
            this.lbl_customermobilenumber.AutoSize = true;
            this.lbl_customermobilenumber.Location = new System.Drawing.Point(34, 216);
            this.lbl_customermobilenumber.Name = "lbl_customermobilenumber";
            this.lbl_customermobilenumber.Size = new System.Drawing.Size(125, 13);
            this.lbl_customermobilenumber.TabIndex = 4;
            this.lbl_customermobilenumber.Text = "Customer Mobile Number";
            // 
            // lbl_customeremailid
            // 
            this.lbl_customeremailid.AutoSize = true;
            this.lbl_customeremailid.Location = new System.Drawing.Point(36, 260);
            this.lbl_customeremailid.Name = "lbl_customeremailid";
            this.lbl_customeremailid.Size = new System.Drawing.Size(90, 13);
            this.lbl_customeremailid.TabIndex = 5;
            this.lbl_customeremailid.Text = "Customer EmailID";
            // 
            // txt_Customerpassword
            // 
            this.txt_Customerpassword.Location = new System.Drawing.Point(165, 92);
            this.txt_Customerpassword.Name = "txt_Customerpassword";
            this.txt_Customerpassword.Size = new System.Drawing.Size(144, 20);
            this.txt_Customerpassword.TabIndex = 7;
            // 
            // txt_customeradress
            // 
            this.txt_customeradress.Location = new System.Drawing.Point(165, 171);
            this.txt_customeradress.Name = "txt_customeradress";
            this.txt_customeradress.Size = new System.Drawing.Size(143, 20);
            this.txt_customeradress.TabIndex = 9;
            // 
            // txt_customermobilenumber
            // 
            this.txt_customermobilenumber.Location = new System.Drawing.Point(165, 213);
            this.txt_customermobilenumber.Name = "txt_customermobilenumber";
            this.txt_customermobilenumber.Size = new System.Drawing.Size(144, 20);
            this.txt_customermobilenumber.TabIndex = 10;
            // 
            // txt_customeremailid
            // 
            this.txt_customeremailid.Location = new System.Drawing.Point(164, 253);
            this.txt_customeremailid.Name = "txt_customeremailid";
            this.txt_customeremailid.Size = new System.Drawing.Size(143, 20);
            this.txt_customeremailid.TabIndex = 11;
            // 
            // btn_newcustomer
            // 
            this.btn_newcustomer.Location = new System.Drawing.Point(358, 74);
            this.btn_newcustomer.Name = "btn_newcustomer";
            this.btn_newcustomer.Size = new System.Drawing.Size(108, 23);
            this.btn_newcustomer.TabIndex = 13;
            this.btn_newcustomer.Text = "New Customer";
            this.btn_newcustomer.UseVisualStyleBackColor = true;
            this.btn_newcustomer.Click += new System.EventHandler(this.btn_newcustomer_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(380, 135);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_reset.TabIndex = 14;
            this.btn_reset.Text = "Reset\r\n";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // txt_customername
            // 
            this.txt_customername.Location = new System.Drawing.Point(165, 60);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(144, 20);
            this.txt_customername.TabIndex = 15;
            // 
            // txt_customercity
            // 
            this.txt_customercity.Location = new System.Drawing.Point(164, 135);
            this.txt_customercity.Name = "txt_customercity";
            this.txt_customercity.Size = new System.Drawing.Size(143, 20);
            this.txt_customercity.TabIndex = 16;
            // 
            // form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 479);
            this.Controls.Add(this.txt_customercity);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newcustomer);
            this.Controls.Add(this.txt_customeremailid);
            this.Controls.Add(this.txt_customermobilenumber);
            this.Controls.Add(this.txt_customeradress);
            this.Controls.Add(this.txt_Customerpassword);
            this.Controls.Add(this.lbl_customeremailid);
            this.Controls.Add(this.lbl_customermobilenumber);
            this.Controls.Add(this.lbl_customeraddress);
            this.Controls.Add(this.lbl_customercity);
            this.Controls.Add(this.lbl_customerpassword);
            this.Controls.Add(this.lbl_customername);
            this.Name = "form";
            this.Text = "form1";
            this.Load += new System.EventHandler(this.form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_customerpassword;
        private System.Windows.Forms.Label lbl_customercity;
        private System.Windows.Forms.Label lbl_customeraddress;
        private System.Windows.Forms.Label lbl_customermobilenumber;
        private System.Windows.Forms.Label lbl_customeremailid;
        private System.Windows.Forms.TextBox txt_Customerpassword;
        private System.Windows.Forms.TextBox txt_customeradress;
        private System.Windows.Forms.TextBox txt_customermobilenumber;
        private System.Windows.Forms.TextBox txt_customeremailid;
        private System.Windows.Forms.Button btn_newcustomer;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.TextBox txt_customercity;
    }
}

