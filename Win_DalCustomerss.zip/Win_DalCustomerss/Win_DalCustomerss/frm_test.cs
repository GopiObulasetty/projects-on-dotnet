﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_DalCustomerss
{
    public partial class frm_test : Form
    {
        public frm_test()
        {
            InitializeComponent();
        }

        private void frm_test_Load(object sender, EventArgs e)
        {

        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if(txt_customerid.Text==string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int ID = Convert.ToInt32(txt_customerid.Text);
                CustomersDAL dal = new CustomersDAL();
                Customers c = dal.Find(ID);
                if(c!=null)
                {
                    txt_customername.Text = c.CustomerName;
                    txt_Customerpassword.Text = c.CustomerPassWord;
                    txt_customercity.Text = c.CustomerCity;
                    txt_customeradress.Text = c.CustomerAddress;
                    txt_customermobilenumber.Text = c.CustomermobileNumber;
                    txt_customeremailid.Text =c.CustomerEmailID;

                }
                else
                {
                    MessageBox.Show("not found");
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if(txt_customerid.Text==string.Empty)
            {
                MessageBox.Show("enter the Id");
            }
            else if(txt_customeradress.Text==string.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if(txt_customermobilenumber.Text==string.Empty)
            {
                MessageBox.Show("enter mobile number");
            }
            else
            {
                int ID = Convert.ToInt32(txt_customerid.Text);
                string address = txt_customeradress.Text;
                string mobilenumber = txt_customermobilenumber.Text;

                CustomersDAL dal = new CustomersDAL();
                bool status = dal.Update(ID, address, mobilenumber);
                if(status)
                {
                    MessageBox.Show("update");
                }
                else
                {
                    MessageBox.Show("not found");
                }
            }

        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if(txt_customerid.Text==string.Empty)
            {
                MessageBox.Show("entr id");
            }
            else
            {
                int ID = Convert.ToInt32(txt_customerid.Text);
                CustomersDAL dal = new CustomersDAL();
                bool status = dal.Delete(ID);
                if(status)
                {
                    MessageBox.Show("deleted");
                }
                else
                {
                    MessageBox.Show("not found");
                }
            }
        }
    }
}
