﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_DalCustomerss
{
    public partial class frm_showcustomer : Form
    {
        public frm_showcustomer()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            CustomersDAL dal = new CustomersDAL();
            string city = txt_customercity.Text;
            List<Customers> list = dal.showcustomer(city);
            dg_customers.DataSource = list;
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            CustomersDAL dal = new CustomersDAL();
            string search = txt_search.Text;
            List<Customers> list = dal.searchcustomer(search);
            dg_customers.DataSource = list;
        }
    }
    
}
