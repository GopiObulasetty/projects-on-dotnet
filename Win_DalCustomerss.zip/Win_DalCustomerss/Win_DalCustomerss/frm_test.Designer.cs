﻿namespace Win_DalCustomerss
{
    partial class frm_test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_customercity = new System.Windows.Forms.TextBox();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.txt_customeremailid = new System.Windows.Forms.TextBox();
            this.txt_customermobilenumber = new System.Windows.Forms.TextBox();
            this.txt_customeradress = new System.Windows.Forms.TextBox();
            this.txt_Customerpassword = new System.Windows.Forms.TextBox();
            this.lbl_customeremailid = new System.Windows.Forms.Label();
            this.lbl_customermobilenumber = new System.Windows.Forms.Label();
            this.lbl_customeraddress = new System.Windows.Forms.Label();
            this.lbl_customercity = new System.Windows.Forms.Label();
            this.lbl_customerpassword = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            this.lbl_customerid = new System.Windows.Forms.Label();
            this.btn_find = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_customercity
            // 
            this.txt_customercity.Location = new System.Drawing.Point(222, 135);
            this.txt_customercity.Name = "txt_customercity";
            this.txt_customercity.Size = new System.Drawing.Size(143, 20);
            this.txt_customercity.TabIndex = 28;
            // 
            // txt_customername
            // 
            this.txt_customername.Location = new System.Drawing.Point(223, 60);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(144, 20);
            this.txt_customername.TabIndex = 27;
            // 
            // txt_customeremailid
            // 
            this.txt_customeremailid.Location = new System.Drawing.Point(222, 253);
            this.txt_customeremailid.Name = "txt_customeremailid";
            this.txt_customeremailid.Size = new System.Drawing.Size(143, 20);
            this.txt_customeremailid.TabIndex = 26;
            // 
            // txt_customermobilenumber
            // 
            this.txt_customermobilenumber.Location = new System.Drawing.Point(223, 213);
            this.txt_customermobilenumber.Name = "txt_customermobilenumber";
            this.txt_customermobilenumber.Size = new System.Drawing.Size(144, 20);
            this.txt_customermobilenumber.TabIndex = 25;
            // 
            // txt_customeradress
            // 
            this.txt_customeradress.Location = new System.Drawing.Point(223, 171);
            this.txt_customeradress.Name = "txt_customeradress";
            this.txt_customeradress.Size = new System.Drawing.Size(143, 20);
            this.txt_customeradress.TabIndex = 24;
            // 
            // txt_Customerpassword
            // 
            this.txt_Customerpassword.Location = new System.Drawing.Point(223, 92);
            this.txt_Customerpassword.Name = "txt_Customerpassword";
            this.txt_Customerpassword.Size = new System.Drawing.Size(144, 20);
            this.txt_Customerpassword.TabIndex = 23;
            // 
            // lbl_customeremailid
            // 
            this.lbl_customeremailid.AutoSize = true;
            this.lbl_customeremailid.Location = new System.Drawing.Point(94, 260);
            this.lbl_customeremailid.Name = "lbl_customeremailid";
            this.lbl_customeremailid.Size = new System.Drawing.Size(90, 13);
            this.lbl_customeremailid.TabIndex = 22;
            this.lbl_customeremailid.Text = "Customer EmailID";
            // 
            // lbl_customermobilenumber
            // 
            this.lbl_customermobilenumber.AutoSize = true;
            this.lbl_customermobilenumber.Location = new System.Drawing.Point(92, 216);
            this.lbl_customermobilenumber.Name = "lbl_customermobilenumber";
            this.lbl_customermobilenumber.Size = new System.Drawing.Size(125, 13);
            this.lbl_customermobilenumber.TabIndex = 21;
            this.lbl_customermobilenumber.Text = "Customer Mobile Number";
            // 
            // lbl_customeraddress
            // 
            this.lbl_customeraddress.AutoSize = true;
            this.lbl_customeraddress.Location = new System.Drawing.Point(92, 174);
            this.lbl_customeraddress.Name = "lbl_customeraddress";
            this.lbl_customeraddress.Size = new System.Drawing.Size(92, 13);
            this.lbl_customeraddress.TabIndex = 20;
            this.lbl_customeraddress.Text = "Customer Address";
            // 
            // lbl_customercity
            // 
            this.lbl_customercity.AutoSize = true;
            this.lbl_customercity.Location = new System.Drawing.Point(92, 135);
            this.lbl_customercity.Name = "lbl_customercity";
            this.lbl_customercity.Size = new System.Drawing.Size(71, 13);
            this.lbl_customercity.TabIndex = 19;
            this.lbl_customercity.Text = "Customer City";
            // 
            // lbl_customerpassword
            // 
            this.lbl_customerpassword.AutoSize = true;
            this.lbl_customerpassword.Location = new System.Drawing.Point(92, 95);
            this.lbl_customerpassword.Name = "lbl_customerpassword";
            this.lbl_customerpassword.Size = new System.Drawing.Size(103, 13);
            this.lbl_customerpassword.TabIndex = 18;
            this.lbl_customerpassword.Text = "Customer Password:";
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Location = new System.Drawing.Point(92, 60);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(82, 13);
            this.lbl_customername.TabIndex = 17;
            this.lbl_customername.Text = "Customer Name";
            // 
            // txt_customerid
            // 
            this.txt_customerid.Location = new System.Drawing.Point(224, 24);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(142, 20);
            this.txt_customerid.TabIndex = 29;
            // 
            // lbl_customerid
            // 
            this.lbl_customerid.AutoSize = true;
            this.lbl_customerid.Location = new System.Drawing.Point(99, 25);
            this.lbl_customerid.Name = "lbl_customerid";
            this.lbl_customerid.Size = new System.Drawing.Size(65, 13);
            this.lbl_customerid.TabIndex = 30;
            this.lbl_customerid.Text = "Customer ID";
            // 
            // btn_find
            // 
            this.btn_find.Location = new System.Drawing.Point(452, 71);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(81, 23);
            this.btn_find.TabIndex = 31;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // btn_update
            // 
            this.btn_update.Location = new System.Drawing.Point(458, 139);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(75, 23);
            this.btn_update.TabIndex = 32;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(458, 204);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 33;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // frm_test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 445);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.lbl_customerid);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.txt_customercity);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.txt_customeremailid);
            this.Controls.Add(this.txt_customermobilenumber);
            this.Controls.Add(this.txt_customeradress);
            this.Controls.Add(this.txt_Customerpassword);
            this.Controls.Add(this.lbl_customeremailid);
            this.Controls.Add(this.lbl_customermobilenumber);
            this.Controls.Add(this.lbl_customeraddress);
            this.Controls.Add(this.lbl_customercity);
            this.Controls.Add(this.lbl_customerpassword);
            this.Controls.Add(this.lbl_customername);
            this.Name = "frm_test";
            this.Text = "frm_test";
            this.Load += new System.EventHandler(this.frm_test_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_customercity;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.TextBox txt_customeremailid;
        private System.Windows.Forms.TextBox txt_customermobilenumber;
        private System.Windows.Forms.TextBox txt_customeradress;
        private System.Windows.Forms.TextBox txt_Customerpassword;
        private System.Windows.Forms.Label lbl_customeremailid;
        private System.Windows.Forms.Label lbl_customermobilenumber;
        private System.Windows.Forms.Label lbl_customeraddress;
        private System.Windows.Forms.Label lbl_customercity;
        private System.Windows.Forms.Label lbl_customerpassword;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.TextBox txt_customerid;
        private System.Windows.Forms.Label lbl_customerid;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_delete;
    }
}