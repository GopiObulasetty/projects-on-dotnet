﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_DalCustomerss
{
    class Customers
    {
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string CustomerPassWord { get; set; }
        public string CustomerCity { get; set; }
        public string CustomerAddress { get; set; }
        public string CustomermobileNumber { get; set; }
        public string CustomerEmailID { get; set; }



    }
}
