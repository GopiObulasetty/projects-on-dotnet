﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
namespace Win_DalCustomerss
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddCustomer(Customers c)
        {
            SqlCommand com_c_insert = new SqlCommand("insert tbl_Customers values(@name,@password,@city,@address,@mobilenumber,@emailid)", con);
            com_c_insert.Parameters.AddWithValue("@name", c.CustomerName);
            com_c_insert.Parameters.AddWithValue("@password", c.CustomerPassWord);
            com_c_insert.Parameters.AddWithValue("@city", c.CustomerCity);
            com_c_insert.Parameters.AddWithValue("@address", c.CustomerAddress);
            com_c_insert.Parameters.AddWithValue("@mobilenumber", c.CustomermobileNumber);
            com_c_insert.Parameters.AddWithValue("@emailid", c.CustomerEmailID);

            con.Open();
            com_c_insert.ExecuteNonQuery();
            SqlCommand com_id = new SqlCommand("select @@identity", con);
            int ID = Convert.ToInt32(com_id.ExecuteScalar());
            con.Close();
            return ID;
            }
        public Customers Find(int ID)
        {
            SqlCommand com_find = new SqlCommand("select * from tbl_Customers where CustomerID=@id", con);
            com_find.Parameters.AddWithValue("@id", ID);
           
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if (dr.Read())
            {
                Customers c = new Customers();
                c.CustomerID = dr.GetInt32(0);
                c.CustomerName = dr.GetString(1);
                c.CustomerPassWord = dr.GetString(2);
                c.CustomerCity = dr.GetString(3);
                c.CustomerAddress = dr.GetString(4);
                c.CustomermobileNumber = dr.GetString(5);
                c.CustomerEmailID = dr.GetString(6);
                con.Close();
                return c;
                }
            else
            {
                return null;
            }


        }
        public bool Update(int ID,string address,string mobilenumber)
        {
            SqlCommand com_update = new SqlCommand("update tbl_Customers set CustomerAddress=@address,CustomermobileNumber=@mobilenumber where CustomerID=@id",con);
            com_update.Parameters.AddWithValue("@id", ID);
            com_update.Parameters.AddWithValue("@address", address);
            com_update.Parameters.AddWithValue("@mobilenumber", mobilenumber);
            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if(count>0)
            {
                return true;

            }
            else
            {
                return false;
            }


        }

        public bool Delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand("delete tbl_Customers where CustomerID=@ID", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            con.Close();
            if(count>0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }

        public List<Customers> showcustomer(string city)
        {
            SqlCommand com_customers = new SqlCommand("slect * from tbl_Customers where CustomerCity=@city ", con);
            com_customers.Parameters.AddWithValue("@city", city);
            con.Open();
            SqlDataReader dr = com_customers.ExecuteReader();
            List<Customers> cstlist = new List<Customers>();
            while(dr.Read())
            {
                Customers obj = new Customers();
                obj.CustomerID = dr.GetInt32(0);
                obj.CustomerName = dr.GetString(1);
                obj.CustomerPassWord = dr.GetString(2);
                obj.CustomerCity = dr.GetString(3);
                obj.CustomerAddress = dr.GetString(4);
                obj.CustomermobileNumber = dr.GetString(5);
                obj.CustomerEmailID = dr.GetString(6);
                cstlist.Add(obj);
            }
            con.Close();
            return cstlist;
        }

        public List<Customers> searchcustomer(string search)
        {
            SqlCommand com_search = new SqlCommand("select * from tbl_Customers where CustomerID like '%" + search + "%' or CustomerPassword like '%" + search + "%'", con);

            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            List<Customers> cstlist = new List<Customers>();
            while (dr.Read())
            {
                Customers obj = new Customers();
                obj.CustomerID = dr.GetInt32(0);
                obj.CustomerName = dr.GetString(1);
                obj.CustomerPassWord = dr.GetString(2);
                obj.CustomerCity = dr.GetString(3);
                obj.CustomerAddress = dr.GetString(4);
                obj.CustomermobileNumber = dr.GetString(5);
                obj.CustomerEmailID = dr.GetString(6);
                cstlist.Add(obj);
            }
            con.Close();
            return cstlist;
        }







    }
}
