﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Win_DalCustomerss
{
    class CustomerDAL_proc
    {
        SqlConnection con = new SqlConnection
                    (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddCustomer(Customers c)
        {
            SqlCommand com_c_insert = new SqlCommand("proc_addCustumor", con);
            com_c_insert.Parameters.AddWithValue("@name", c.CustomerName);
            com_c_insert.Parameters.AddWithValue("@password", c.CustomerPassWord);
            com_c_insert.Parameters.AddWithValue("@city", c.CustomerCity);
            com_c_insert.Parameters.AddWithValue("@address", c.CustomerAddress);
            com_c_insert.Parameters.AddWithValue("@mobilenumber", c.CustomermobileNumber);
            com_c_insert.Parameters.AddWithValue("@emailid", c.CustomerEmailID);
            com_c_insert.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_c_insert.Parameters.Add(retdata);

            
            con.Open();
            com_c_insert.ExecuteNonQuery();
            con.Close();
            int ID = Convert.ToInt32(retdata.Value);
            
            return ID;
        }
        public Customers Find(int ID)
        {
            SqlCommand com_find = new SqlCommand("proc_customerdetails", con);
            com_find.Parameters.AddWithValue("@id", ID);
            com_find.CommandType = CommandType.StoredProcedure;


            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if (dr.Read())
            {
                Customers c = new Customers();
                c.CustomerID = dr.GetInt32(0);
                c.CustomerName = dr.GetString(1);
                c.CustomerPassWord = dr.GetString(2);
                c.CustomerCity = dr.GetString(3);
                c.CustomerAddress = dr.GetString(4);
                c.CustomermobileNumber = dr.GetString(5);
                c.CustomerEmailID = dr.GetString(6);
                con.Close();
                return c;
            }
            else
            {
                return null;
            }


        }
        public bool Update(int ID, string address, string mobilenumber)
        {
            SqlCommand com_update = new SqlCommand("proc_updatecustomer", con);
            com_update.Parameters.AddWithValue("@id", ID);
            com_update.Parameters.AddWithValue("@address", address);
            com_update.Parameters.AddWithValue("@mobilenumber", mobilenumber);

            com_update.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_update.Parameters.Add(retdata);


           con.Open();
            com_update.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);
            if (count > 0)
            {
                return true;

            }
            else
            {
                return false;
            }


        }

        public bool Delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand("delete tbl_Customers where CustomerID=@ID", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            com_delete.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_delete.Parameters.Add(retdata);
            con.Open();
            com_delete.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);
            if (count > 0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }


        public List<Customers> showcustomer(string city)
        {
            SqlCommand com_customers = new SqlCommand("proc_showcustomer", con);
            com_customers.Parameters.AddWithValue("@city", city);
            com_customers.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_customers.ExecuteReader();
            List<Customers> cstlist = new List<Customers>();
            while (dr.Read())
            {
                Customers obj = new Customers();
                obj.CustomerID = dr.GetInt32(0);
                obj.CustomerName = dr.GetString(1);
                obj.CustomerPassWord = dr.GetString(2);
                obj.CustomerCity = dr.GetString(3);
                obj.CustomerAddress = dr.GetString(4);
                obj.CustomermobileNumber = dr.GetString(5);
                obj.CustomerEmailID = dr.GetString(6);
                cstlist.Add(obj);
            }
            con.Close();
            return cstlist;
        }



        public List<Customers> searchcustomer(string search)
        {
            SqlCommand com_search = new SqlCommand("proc_searchcustomer", con);
            com_search.Parameters.AddWithValue("@kay", search);
            com_search.CommandType = CommandType.StoredProcedure;
           
            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            List<Customers> cstlist = new List<Customers>();
            while (dr.Read())
            {
                Customers obj = new Customers();
                obj.CustomerID = dr.GetInt32(0);
                obj.CustomerName = dr.GetString(1);
                obj.CustomerPassWord = dr.GetString(2);
                obj.CustomerCity = dr.GetString(3);
                obj.CustomerAddress = dr.GetString(4);
                obj.CustomermobileNumber = dr.GetString(5);
                obj.CustomerEmailID = dr.GetString(6);
                cstlist.Add(obj);
            }
            con.Close();
            return cstlist;
        }

    }
}

