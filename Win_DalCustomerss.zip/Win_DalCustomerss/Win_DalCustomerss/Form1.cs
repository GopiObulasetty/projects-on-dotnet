﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_DalCustomerss
{
    public partial class form : Form
    {
        public form()
        {
            InitializeComponent();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_customername.Text = string.Empty;
            txt_Customerpassword.Text = string.Empty;
            txt_customercity.Text = string.Empty;
            txt_customeradress.Text = string.Empty;
            txt_customermobilenumber.Text = string.Empty;
            txt_customeremailid.Text = string.Empty;

        }

        private void btn_newcustomer_Click(object sender, EventArgs e)
        {
            if (txt_customername.Text == string.Empty)
            {
                MessageBox.Show("enter name");
            }
            else if (txt_Customerpassword.Text == string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else if (txt_customercity.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if (txt_customeradress.Text == string.Empty)
            {
                MessageBox.Show("enter addres");
            }
            else if (txt_customermobilenumber.Text == string.Empty) 
            {
                MessageBox.Show("enter mobile no");
            }
            else if (txt_customeremailid.Text == string.Empty)
            {
                MessageBox.Show("enter email");
            }
            else
            {
                string name = txt_customername.Text;
                string password = txt_Customerpassword.Text;
                string city = txt_customercity.Text;
                string address = txt_customeradress.Text;
                string mobileno = txt_customermobilenumber.Text;
                string email = txt_customeremailid.Text;

                Customers obj = new Customers();
                obj.CustomerName = name;
                obj.CustomerPassWord = password;
                obj.CustomerCity = city;
                obj.CustomerAddress = address;
                obj.CustomermobileNumber = mobileno;
                obj.CustomerEmailID = email;

                CustomersDAL dal = new CustomersDAL();
                int id = dal.AddCustomer(obj);
                MessageBox.Show("customer add" + id);

            }
        }

        private void form_Load(object sender, EventArgs e)
        {

        }
    }
}
