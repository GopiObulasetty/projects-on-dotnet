﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Office
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the EmployeeID:");
            int EmployeeID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the Employeename");
            string EmployeeName = Console.ReadLine();
            Console.WriteLine("enter the EMP city:");
            string Empcity= Console.ReadLine();
            Console.WriteLine("emp salry:");
            double Empsal = Convert.ToInt32(Console.ReadLine());

            Employee obj = new Employee(EmployeeID, EmployeeName, Empcity, Empsal);

            Console.WriteLine("enter the no of dayys");
            int Noofdays = Convert.ToInt32(Console.ReadLine());


            double EmpSalary = obj.GetEmployeeSalary( Noofdays);
          
            Console.WriteLine("emp salary:" + EmpSalary);

            string Details = obj.GetDetails();
            Console.WriteLine("Emp details:" + Details);

            Console.ReadLine();
        }
    }
}
