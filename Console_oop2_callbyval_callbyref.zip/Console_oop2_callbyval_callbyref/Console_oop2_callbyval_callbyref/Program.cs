﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop2_callbyval_callbyref
{
    class Program
    {
        static void Main(string[] args)
        {
            XYZ obj1 = new XYZ();
            obj1.Call();

            int[] marks = new int[3];
            marks[0] = 10;
            marks[1] = 20;
            marks[2] = 30;

            Test obj = new Test();
            obj.CallArry(10,40,66,99);

            int OrderAmt = obj.GetOrderValue(ItemPrice:1000,ItemQty:2);
            Console.WriteLine(OrderAmt);

            int x = 100;
            obj.Call(ref x);
            Console.WriteLine(x);
            Console.ReadLine();
        


        }
    }
}
