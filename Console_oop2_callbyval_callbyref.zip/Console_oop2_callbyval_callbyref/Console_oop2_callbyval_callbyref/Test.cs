﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop2_callbyval_callbyref
{
    class Test
    {
        public void Call(ref int Amt)
        {
            Console.WriteLine(Amt);
        }
        public void CallArry(params int[] marks)
        {

            foreach (int m in marks)
            {
                Console.WriteLine(m);
            }
        }
        public int GetOrderValue(int ItemPrice,int ItemQty)
        {
            return ItemQty * ItemPrice;
        }


        }

    }
 