﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dot_net
{
    class bank
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the item name:");
            string itemname = Console.ReadLine();
            Console.WriteLine("enter the qty:");
            int qty = Convert.ToInt32(Console.ReadLine());
            if (qty < 1)
            {
                Console.WriteLine("invalid qty:");
            }
            else
            {
                Console.WriteLine("enter the qty:");
            }
            Console.ReadLine();




        }
    }
}
