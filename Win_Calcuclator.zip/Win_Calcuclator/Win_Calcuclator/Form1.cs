﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Calcuclator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("enter number1");

            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("enter number2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);

                CalculatorLibrary.Calculator obj = new CalculatorLibrary.Calculator();
                int sub = obj.GetSubstract(num1, num2);
                lbl_substraction.Text = sub.ToString();


            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_getsum_Click(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("enter number1");

            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("enter number2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);

                CalculatorLibrary.Calculator obj = new CalculatorLibrary.Calculator();
                int sum = obj.GetSum(num1, num2);
                lbl_getsum.Text = sum.ToString();


            }
        }

        private void btn_getmultiple_Click(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("enter number1");

            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("enter number2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);

                CalculatorLibrary.Calculator obj = new CalculatorLibrary.Calculator();
                int mul = obj.GetMultiple(num1, num2);
                lbl_getmultiple.Text = mul.ToString();


            }
        }

        private void btn_getdivided_Click(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("enter number1");

            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("enter number2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);

                CalculatorLibrary.Calculator obj = new CalculatorLibrary.Calculator();
                int dvd = obj.Getdivided(num1, num2);
                lbl_getdivided.Text = dvd.ToString();


            }
        }
    }
}
