﻿namespace Win_Calcuclator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Number1 = new System.Windows.Forms.Label();
            this.lbl_number2 = new System.Windows.Forms.Label();
            this.txt_number1 = new System.Windows.Forms.TextBox();
            this.txt_number2 = new System.Windows.Forms.TextBox();
            this.btn_getsum = new System.Windows.Forms.Button();
            this.btn_getmultiple = new System.Windows.Forms.Button();
            this.btn_getdivided = new System.Windows.Forms.Button();
            this.btn_getsubstract = new System.Windows.Forms.Button();
            this.lbl_getsum = new System.Windows.Forms.Label();
            this.lbl_getmultiple = new System.Windows.Forms.Label();
            this.lbl_getdivided = new System.Windows.Forms.Label();
            this.lbl_substraction = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_Number1
            // 
            this.lbl_Number1.AutoSize = true;
            this.lbl_Number1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Number1.Location = new System.Drawing.Point(101, 52);
            this.lbl_Number1.Name = "lbl_Number1";
            this.lbl_Number1.Size = new System.Drawing.Size(70, 17);
            this.lbl_Number1.TabIndex = 0;
            this.lbl_Number1.Text = "Number1:";
            // 
            // lbl_number2
            // 
            this.lbl_number2.AutoSize = true;
            this.lbl_number2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_number2.Location = new System.Drawing.Point(100, 110);
            this.lbl_number2.Name = "lbl_number2";
            this.lbl_number2.Size = new System.Drawing.Size(70, 17);
            this.lbl_number2.TabIndex = 1;
            this.lbl_number2.Text = "Number2:";
            // 
            // txt_number1
            // 
            this.txt_number1.Location = new System.Drawing.Point(202, 51);
            this.txt_number1.Name = "txt_number1";
            this.txt_number1.Size = new System.Drawing.Size(100, 20);
            this.txt_number1.TabIndex = 2;
            // 
            // txt_number2
            // 
            this.txt_number2.Location = new System.Drawing.Point(202, 110);
            this.txt_number2.Name = "txt_number2";
            this.txt_number2.Size = new System.Drawing.Size(100, 20);
            this.txt_number2.TabIndex = 3;
            // 
            // btn_getsum
            // 
            this.btn_getsum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_getsum.Location = new System.Drawing.Point(36, 183);
            this.btn_getsum.Name = "btn_getsum";
            this.btn_getsum.Size = new System.Drawing.Size(75, 23);
            this.btn_getsum.TabIndex = 4;
            this.btn_getsum.Text = "Get Sum";
            this.btn_getsum.UseVisualStyleBackColor = true;
            this.btn_getsum.Click += new System.EventHandler(this.btn_getsum_Click);
            // 
            // btn_getmultiple
            // 
            this.btn_getmultiple.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_getmultiple.Location = new System.Drawing.Point(148, 183);
            this.btn_getmultiple.Name = "btn_getmultiple";
            this.btn_getmultiple.Size = new System.Drawing.Size(102, 23);
            this.btn_getmultiple.TabIndex = 5;
            this.btn_getmultiple.Text = "Get Multiple";
            this.btn_getmultiple.UseVisualStyleBackColor = true;
            this.btn_getmultiple.Click += new System.EventHandler(this.btn_getmultiple_Click);
            // 
            // btn_getdivided
            // 
            this.btn_getdivided.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_getdivided.Location = new System.Drawing.Point(285, 183);
            this.btn_getdivided.Name = "btn_getdivided";
            this.btn_getdivided.Size = new System.Drawing.Size(95, 23);
            this.btn_getdivided.TabIndex = 6;
            this.btn_getdivided.Text = "Get Divided";
            this.btn_getdivided.UseVisualStyleBackColor = true;
            this.btn_getdivided.Click += new System.EventHandler(this.btn_getdivided_Click);
            // 
            // btn_getsubstract
            // 
            this.btn_getsubstract.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_getsubstract.Location = new System.Drawing.Point(398, 183);
            this.btn_getsubstract.Name = "btn_getsubstract";
            this.btn_getsubstract.Size = new System.Drawing.Size(119, 23);
            this.btn_getsubstract.TabIndex = 7;
            this.btn_getsubstract.Text = "Get Substract";
            this.btn_getsubstract.UseVisualStyleBackColor = true;
            this.btn_getsubstract.Click += new System.EventHandler(this.button4_Click);
            // 
            // lbl_getsum
            // 
            this.lbl_getsum.AutoSize = true;
            this.lbl_getsum.Location = new System.Drawing.Point(59, 254);
            this.lbl_getsum.Name = "lbl_getsum";
            this.lbl_getsum.Size = new System.Drawing.Size(38, 13);
            this.lbl_getsum.TabIndex = 8;
            this.lbl_getsum.Text = "Sum is";
            // 
            // lbl_getmultiple
            // 
            this.lbl_getmultiple.AutoSize = true;
            this.lbl_getmultiple.Location = new System.Drawing.Point(180, 254);
            this.lbl_getmultiple.Name = "lbl_getmultiple";
            this.lbl_getmultiple.Size = new System.Drawing.Size(70, 13);
            this.lbl_getmultiple.TabIndex = 9;
            this.lbl_getmultiple.Text = "Mltiplection is";
            this.lbl_getmultiple.Click += new System.EventHandler(this.label2_Click);
            // 
            // lbl_getdivided
            // 
            this.lbl_getdivided.AutoSize = true;
            this.lbl_getdivided.Location = new System.Drawing.Point(305, 254);
            this.lbl_getdivided.Name = "lbl_getdivided";
            this.lbl_getdivided.Size = new System.Drawing.Size(41, 13);
            this.lbl_getdivided.TabIndex = 10;
            this.lbl_getdivided.Text = "divided";
            // 
            // lbl_substraction
            // 
            this.lbl_substraction.AutoSize = true;
            this.lbl_substraction.Location = new System.Drawing.Point(422, 254);
            this.lbl_substraction.Name = "lbl_substraction";
            this.lbl_substraction.Size = new System.Drawing.Size(70, 13);
            this.lbl_substraction.TabIndex = 11;
            this.lbl_substraction.Text = "Substrction is";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 447);
            this.Controls.Add(this.lbl_substraction);
            this.Controls.Add(this.lbl_getdivided);
            this.Controls.Add(this.lbl_getmultiple);
            this.Controls.Add(this.lbl_getsum);
            this.Controls.Add(this.btn_getsubstract);
            this.Controls.Add(this.btn_getdivided);
            this.Controls.Add(this.btn_getmultiple);
            this.Controls.Add(this.btn_getsum);
            this.Controls.Add(this.txt_number2);
            this.Controls.Add(this.txt_number1);
            this.Controls.Add(this.lbl_number2);
            this.Controls.Add(this.lbl_Number1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Number1;
        private System.Windows.Forms.Label lbl_number2;
        private System.Windows.Forms.TextBox txt_number1;
        private System.Windows.Forms.TextBox txt_number2;
        private System.Windows.Forms.Button btn_getsum;
        private System.Windows.Forms.Button btn_getmultiple;
        private System.Windows.Forms.Button btn_getdivided;
        private System.Windows.Forms.Button btn_getsubstract;
        private System.Windows.Forms.Label lbl_getsum;
        private System.Windows.Forms.Label lbl_getmultiple;
        private System.Windows.Forms.Label lbl_getdivided;
        private System.Windows.Forms.Label lbl_substraction;
    }
}

