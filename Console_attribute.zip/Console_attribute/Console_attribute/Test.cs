﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_attribute
{
    [Developer("1001","john")]
    class Test
    {
        [Obsolete("not in use,usexyz")]
        [Developer("1002","David")]
        public void call()
        {
            Console.WriteLine("call function called");
        }
    }
}
