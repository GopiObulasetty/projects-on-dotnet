﻿namespace Win_serialization
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_productid = new System.Windows.Forms.Label();
            this.lbl_productname = new System.Windows.Forms.Label();
            this.lbl_productprice = new System.Windows.Forms.Label();
            this.txt_productid = new System.Windows.Forms.TextBox();
            this.txt_productname = new System.Windows.Forms.TextBox();
            this.txt_productprice = new System.Windows.Forms.TextBox();
            this.btn_serialize = new System.Windows.Forms.Button();
            this.btn_deserialize = new System.Windows.Forms.Button();
            this.btn_xmldeseializer = new System.Windows.Forms.Button();
            this.btn_xmlserialize = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_productid
            // 
            this.lbl_productid.AutoSize = true;
            this.lbl_productid.Location = new System.Drawing.Point(103, 57);
            this.lbl_productid.Name = "lbl_productid";
            this.lbl_productid.Size = new System.Drawing.Size(61, 13);
            this.lbl_productid.TabIndex = 0;
            this.lbl_productid.Text = "Product ID:";
            // 
            // lbl_productname
            // 
            this.lbl_productname.AutoSize = true;
            this.lbl_productname.Location = new System.Drawing.Point(104, 108);
            this.lbl_productname.Name = "lbl_productname";
            this.lbl_productname.Size = new System.Drawing.Size(75, 13);
            this.lbl_productname.TabIndex = 1;
            this.lbl_productname.Text = "ProductName:";
            // 
            // lbl_productprice
            // 
            this.lbl_productprice.AutoSize = true;
            this.lbl_productprice.Location = new System.Drawing.Point(104, 156);
            this.lbl_productprice.Name = "lbl_productprice";
            this.lbl_productprice.Size = new System.Drawing.Size(71, 13);
            this.lbl_productprice.TabIndex = 2;
            this.lbl_productprice.Text = "Product Price";
            // 
            // txt_productid
            // 
            this.txt_productid.Location = new System.Drawing.Point(200, 58);
            this.txt_productid.Name = "txt_productid";
            this.txt_productid.Size = new System.Drawing.Size(100, 20);
            this.txt_productid.TabIndex = 3;
            // 
            // txt_productname
            // 
            this.txt_productname.Location = new System.Drawing.Point(200, 101);
            this.txt_productname.Name = "txt_productname";
            this.txt_productname.Size = new System.Drawing.Size(100, 20);
            this.txt_productname.TabIndex = 4;
            // 
            // txt_productprice
            // 
            this.txt_productprice.Location = new System.Drawing.Point(200, 149);
            this.txt_productprice.Name = "txt_productprice";
            this.txt_productprice.Size = new System.Drawing.Size(100, 20);
            this.txt_productprice.TabIndex = 5;
            // 
            // btn_serialize
            // 
            this.btn_serialize.Location = new System.Drawing.Point(120, 225);
            this.btn_serialize.Name = "btn_serialize";
            this.btn_serialize.Size = new System.Drawing.Size(75, 23);
            this.btn_serialize.TabIndex = 6;
            this.btn_serialize.Text = "Serialize";
            this.btn_serialize.UseVisualStyleBackColor = true;
            this.btn_serialize.Click += new System.EventHandler(this.btn_serialize_Click);
            // 
            // btn_deserialize
            // 
            this.btn_deserialize.Location = new System.Drawing.Point(280, 225);
            this.btn_deserialize.Name = "btn_deserialize";
            this.btn_deserialize.Size = new System.Drawing.Size(75, 23);
            this.btn_deserialize.TabIndex = 7;
            this.btn_deserialize.Text = "Deserialize";
            this.btn_deserialize.UseVisualStyleBackColor = true;
            this.btn_deserialize.Click += new System.EventHandler(this.btn_deserialize_Click);
            // 
            // btn_xmldeseializer
            // 
            this.btn_xmldeseializer.Location = new System.Drawing.Point(280, 279);
            this.btn_xmldeseializer.Name = "btn_xmldeseializer";
            this.btn_xmldeseializer.Size = new System.Drawing.Size(132, 23);
            this.btn_xmldeseializer.TabIndex = 9;
            this.btn_xmldeseializer.Text = "XML Deserialize";
            this.btn_xmldeseializer.UseVisualStyleBackColor = true;
            this.btn_xmldeseializer.Click += new System.EventHandler(this.btn_xmldeseializer_Click);
            // 
            // btn_xmlserialize
            // 
            this.btn_xmlserialize.Location = new System.Drawing.Point(120, 279);
            this.btn_xmlserialize.Name = "btn_xmlserialize";
            this.btn_xmlserialize.Size = new System.Drawing.Size(75, 23);
            this.btn_xmlserialize.TabIndex = 8;
            this.btn_xmlserialize.Text = "Xml Serialize";
            this.btn_xmlserialize.UseVisualStyleBackColor = true;
            this.btn_xmlserialize.Click += new System.EventHandler(this.btn_xmlserialize_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 370);
            this.Controls.Add(this.btn_xmldeseializer);
            this.Controls.Add(this.btn_xmlserialize);
            this.Controls.Add(this.btn_deserialize);
            this.Controls.Add(this.btn_serialize);
            this.Controls.Add(this.txt_productprice);
            this.Controls.Add(this.txt_productname);
            this.Controls.Add(this.txt_productid);
            this.Controls.Add(this.lbl_productprice);
            this.Controls.Add(this.lbl_productname);
            this.Controls.Add(this.lbl_productid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_productid;
        private System.Windows.Forms.Label lbl_productname;
        private System.Windows.Forms.Label lbl_productprice;
        private System.Windows.Forms.TextBox txt_productid;
        private System.Windows.Forms.TextBox txt_productname;
        private System.Windows.Forms.TextBox txt_productprice;
        private System.Windows.Forms.Button btn_serialize;
        private System.Windows.Forms.Button btn_deserialize;
        private System.Windows.Forms.Button btn_xmldeseializer;
        private System.Windows.Forms.Button btn_xmlserialize;
    }
}

