﻿namespace Win_ManageStudents
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.lbl_studentid = new System.Windows.Forms.Label();
            this.lbl_studentname = new System.Windows.Forms.Label();
            this.lbl_studentaddress = new System.Windows.Forms.Label();
            this.lbl_studentemailid = new System.Windows.Forms.Label();
            this.txt_situdentid = new System.Windows.Forms.TextBox();
            this.txt_studentname = new System.Windows.Forms.TextBox();
            this.txt_studentadress = new System.Windows.Forms.TextBox();
            this.txt_studentemailid = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_update
            // 
            this.btn_update.Location = new System.Drawing.Point(343, 162);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(75, 23);
            this.btn_update.TabIndex = 1;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_find
            // 
            this.btn_find.Location = new System.Drawing.Point(343, 105);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(75, 23);
            this.btn_find.TabIndex = 2;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(343, 214);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 3;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // lbl_studentid
            // 
            this.lbl_studentid.AutoSize = true;
            this.lbl_studentid.Location = new System.Drawing.Point(32, 62);
            this.lbl_studentid.Name = "lbl_studentid";
            this.lbl_studentid.Size = new System.Drawing.Size(58, 13);
            this.lbl_studentid.TabIndex = 4;
            this.lbl_studentid.Text = "Student ID";
            this.lbl_studentid.Click += new System.EventHandler(this.lbl_studentid_Click);
            // 
            // lbl_studentname
            // 
            this.lbl_studentname.AutoSize = true;
            this.lbl_studentname.Location = new System.Drawing.Point(32, 115);
            this.lbl_studentname.Name = "lbl_studentname";
            this.lbl_studentname.Size = new System.Drawing.Size(75, 13);
            this.lbl_studentname.TabIndex = 5;
            this.lbl_studentname.Text = "Student Name";
            this.lbl_studentname.Click += new System.EventHandler(this.lbl_studentname_Click);
            // 
            // lbl_studentaddress
            // 
            this.lbl_studentaddress.AutoSize = true;
            this.lbl_studentaddress.Location = new System.Drawing.Point(24, 172);
            this.lbl_studentaddress.Name = "lbl_studentaddress";
            this.lbl_studentaddress.Size = new System.Drawing.Size(85, 13);
            this.lbl_studentaddress.TabIndex = 6;
            this.lbl_studentaddress.Text = "Student Address";
            this.lbl_studentaddress.Click += new System.EventHandler(this.lbl_studentaddress_Click);
            // 
            // lbl_studentemailid
            // 
            this.lbl_studentemailid.AutoSize = true;
            this.lbl_studentemailid.Location = new System.Drawing.Point(24, 219);
            this.lbl_studentemailid.Name = "lbl_studentemailid";
            this.lbl_studentemailid.Size = new System.Drawing.Size(83, 13);
            this.lbl_studentemailid.TabIndex = 7;
            this.lbl_studentemailid.Text = "Student EmailID";
            this.lbl_studentemailid.Click += new System.EventHandler(this.lbl_studentemailid_Click);
            // 
            // txt_situdentid
            // 
            this.txt_situdentid.Location = new System.Drawing.Point(133, 62);
            this.txt_situdentid.Name = "txt_situdentid";
            this.txt_situdentid.Size = new System.Drawing.Size(100, 20);
            this.txt_situdentid.TabIndex = 8;
            this.txt_situdentid.Text = "00";
            this.txt_situdentid.TextChanged += new System.EventHandler(this.txt_situdentid_TextChanged);
            // 
            // txt_studentname
            // 
            this.txt_studentname.Location = new System.Drawing.Point(133, 107);
            this.txt_studentname.Name = "txt_studentname";
            this.txt_studentname.Size = new System.Drawing.Size(100, 20);
            this.txt_studentname.TabIndex = 9;
            this.txt_studentname.TextChanged += new System.EventHandler(this.txt_studentname_TextChanged);
            // 
            // txt_studentadress
            // 
            this.txt_studentadress.Location = new System.Drawing.Point(133, 164);
            this.txt_studentadress.Name = "txt_studentadress";
            this.txt_studentadress.Size = new System.Drawing.Size(100, 20);
            this.txt_studentadress.TabIndex = 10;
            this.txt_studentadress.TextChanged += new System.EventHandler(this.txt_studentadress_TextChanged);
            // 
            // txt_studentemailid
            // 
            this.txt_studentemailid.Location = new System.Drawing.Point(133, 214);
            this.txt_studentemailid.Name = "txt_studentemailid";
            this.txt_studentemailid.Size = new System.Drawing.Size(100, 20);
            this.txt_studentemailid.TabIndex = 11;
            this.txt_studentemailid.TextChanged += new System.EventHandler(this.txt_studentemailid_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 427);
            this.Controls.Add(this.txt_studentemailid);
            this.Controls.Add(this.txt_studentadress);
            this.Controls.Add(this.txt_studentname);
            this.Controls.Add(this.txt_situdentid);
            this.Controls.Add(this.lbl_studentemailid);
            this.Controls.Add(this.lbl_studentaddress);
            this.Controls.Add(this.lbl_studentname);
            this.Controls.Add(this.lbl_studentid);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.btn_update);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Label lbl_studentid;
        private System.Windows.Forms.Label lbl_studentname;
        private System.Windows.Forms.Label lbl_studentaddress;
        private System.Windows.Forms.Label lbl_studentemailid;
        private System.Windows.Forms.TextBox txt_situdentid;
        private System.Windows.Forms.TextBox txt_studentname;
        private System.Windows.Forms.TextBox txt_studentadress;
        private System.Windows.Forms.TextBox txt_studentemailid;
    }
}

