﻿namespace Win_ManageStudents
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_reset = new System.Windows.Forms.Button();
            this.txt_studentemailid = new System.Windows.Forms.TextBox();
            this.txt_studentadress = new System.Windows.Forms.TextBox();
            this.txt_studentname = new System.Windows.Forms.TextBox();
            this.lbl_studentemailid = new System.Windows.Forms.Label();
            this.lbl_studentaddress = new System.Windows.Forms.Label();
            this.lbl_studentname = new System.Windows.Forms.Label();
            this.btn_newstudent = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(138, 263);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_reset.TabIndex = 22;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // txt_studentemailid
            // 
            this.txt_studentemailid.Location = new System.Drawing.Point(138, 212);
            this.txt_studentemailid.Name = "txt_studentemailid";
            this.txt_studentemailid.Size = new System.Drawing.Size(100, 20);
            this.txt_studentemailid.TabIndex = 21;
            this.txt_studentemailid.TextChanged += new System.EventHandler(this.txt_studentemailid_TextChanged);
            // 
            // txt_studentadress
            // 
            this.txt_studentadress.Location = new System.Drawing.Point(138, 162);
            this.txt_studentadress.Name = "txt_studentadress";
            this.txt_studentadress.Size = new System.Drawing.Size(100, 20);
            this.txt_studentadress.TabIndex = 20;
            this.txt_studentadress.TextChanged += new System.EventHandler(this.txt_studentadress_TextChanged);
            // 
            // txt_studentname
            // 
            this.txt_studentname.Location = new System.Drawing.Point(138, 105);
            this.txt_studentname.Name = "txt_studentname";
            this.txt_studentname.Size = new System.Drawing.Size(100, 20);
            this.txt_studentname.TabIndex = 19;
            this.txt_studentname.TextChanged += new System.EventHandler(this.txt_studentname_TextChanged);
            // 
            // lbl_studentemailid
            // 
            this.lbl_studentemailid.AutoSize = true;
            this.lbl_studentemailid.Location = new System.Drawing.Point(29, 217);
            this.lbl_studentemailid.Name = "lbl_studentemailid";
            this.lbl_studentemailid.Size = new System.Drawing.Size(83, 13);
            this.lbl_studentemailid.TabIndex = 17;
            this.lbl_studentemailid.Text = "Student EmailID";
            this.lbl_studentemailid.Click += new System.EventHandler(this.lbl_studentemailid_Click);
            // 
            // lbl_studentaddress
            // 
            this.lbl_studentaddress.AutoSize = true;
            this.lbl_studentaddress.Location = new System.Drawing.Point(29, 170);
            this.lbl_studentaddress.Name = "lbl_studentaddress";
            this.lbl_studentaddress.Size = new System.Drawing.Size(85, 13);
            this.lbl_studentaddress.TabIndex = 16;
            this.lbl_studentaddress.Text = "Student Address";
            this.lbl_studentaddress.Click += new System.EventHandler(this.lbl_studentaddress_Click);
            // 
            // lbl_studentname
            // 
            this.lbl_studentname.AutoSize = true;
            this.lbl_studentname.Location = new System.Drawing.Point(37, 113);
            this.lbl_studentname.Name = "lbl_studentname";
            this.lbl_studentname.Size = new System.Drawing.Size(75, 13);
            this.lbl_studentname.TabIndex = 15;
            this.lbl_studentname.Text = "Student Name";
            this.lbl_studentname.Click += new System.EventHandler(this.lbl_studentname_Click);
            // 
            // btn_newstudent
            // 
            this.btn_newstudent.Location = new System.Drawing.Point(333, 55);
            this.btn_newstudent.Name = "btn_newstudent";
            this.btn_newstudent.Size = new System.Drawing.Size(90, 23);
            this.btn_newstudent.TabIndex = 13;
            this.btn_newstudent.Text = "New Student";
            this.btn_newstudent.UseVisualStyleBackColor = true;
            this.btn_newstudent.Click += new System.EventHandler(this.btn_newstudent_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 340);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.txt_studentemailid);
            this.Controls.Add(this.txt_studentadress);
            this.Controls.Add(this.txt_studentname);
            this.Controls.Add(this.lbl_studentemailid);
            this.Controls.Add(this.lbl_studentaddress);
            this.Controls.Add(this.lbl_studentname);
            this.Controls.Add(this.btn_newstudent);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.TextBox txt_studentemailid;
        private System.Windows.Forms.TextBox txt_studentadress;
        private System.Windows.Forms.TextBox txt_studentname;
        private System.Windows.Forms.Label lbl_studentemailid;
        private System.Windows.Forms.Label lbl_studentaddress;
        private System.Windows.Forms.Label lbl_studentname;
        private System.Windows.Forms.Button btn_newstudent;
    }
}