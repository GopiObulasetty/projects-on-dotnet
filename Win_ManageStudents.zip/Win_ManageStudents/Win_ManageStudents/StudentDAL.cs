﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;




namespace Win_ManageStudents
{
    class StudentDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddStudent(student stu)
        {
            SqlCommand com_stu_insert = new SqlCommand("insert tbl_students values(@name,@address,@email)", con);
            com_stu_insert.Parameters.AddWithValue("@name", stu.studentname);
            com_stu_insert.Parameters.AddWithValue("@address", stu.studentaddress);
            com_stu_insert.Parameters.AddWithValue("@email", stu.studentemailID);

            con.Open();
            com_stu_insert.ExecuteNonQuery();
            SqlCommand com_id = new SqlCommand("select @@identity", con);
            int ID = Convert.ToInt32(com_id.ExecuteScalar());
            con.Close();
            return ID;
        }


        public student Find(int ID)
        {
            SqlCommand com_find = new SqlCommand(" select * from tbl_students where studentID=@id", con);
            com_find.Parameters.AddWithValue("@id", ID);
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if(dr.Read())
            {
                student s = new student();
                s.studentID = dr.GetInt32(0);
                s.studentname = dr.GetString(1);
                s.studentaddress = dr.GetString(2);
                s.studentemailID = dr.GetString(3);
                con.Close();
                return s;
            }
            else
            {
                return null;
            }


        }

        public bool Update(int ID,string address,string email)
        {
            SqlCommand com_update = new SqlCommand("update tbl_students set studentaddress=@address,studentemailID=@email where studentID=@ID",con);
            com_update.Parameters.AddWithValue("@ID", ID);
            com_update.Parameters.AddWithValue("@address", address);
            com_update.Parameters.AddWithValue("@email", email);
            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        public bool Delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand("delete tbl_students where studentID=@ID", con);
            com_delete.Parameters.AddWithValue("@ID", ID);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            con.Close();
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;

            }
        }
    }
}
