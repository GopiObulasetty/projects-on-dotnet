﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ManageStudents
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_newstudent_Click(object sender, EventArgs e)
        {
            
             if (txt_studentname.Text == string.Empty)
            {
                MessageBox.Show("enter student name");
            }
            else if (txt_studentadress.Text == string.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if (txt_studentemailid.Text == string.Empty)
            {
                MessageBox.Show("enter emai");
            }
            else
            {
                string name = txt_studentname.Text;
                string address = txt_studentadress.Text;
                string email = txt_studentemailid.Text;

                student obj = new student();
                obj.studentname = name;
                obj.studentaddress = address;
                obj.studentemailID = email;

                StudentDAL dal = new StudentDAL();
                int ID = dal.AddStudent(obj);
                MessageBox.Show("student add" + ID);

            }

        }

        private void txt_studentemailid_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_studentadress_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_studentname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_situdentid_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_studentemailid_Click(object sender, EventArgs e)
        {

        }

        private void lbl_studentaddress_Click(object sender, EventArgs e)
        {

        }

        private void lbl_studentname_Click(object sender, EventArgs e)
        {

        }

        private void lbl_studentid_Click(object sender, EventArgs e)
        {

        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_studentname.Text = string.Empty;
            txt_studentadress.Text = string.Empty;
            txt_studentemailid.Text = string.Empty;

        }
    }
}
