﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ManageStudents
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_newstudent_Click(object sender, EventArgs e)
        {
            if(txt_situdentid.Text==string.Empty)
            {
                MessageBox.Show("enter student Id");
            }
            else if(txt_studentname.Text==string.Empty)
            {
                MessageBox.Show("enter student name");
            }
            else if(txt_studentadress.Text==string.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if(txt_studentemailid.Text==string.Empty)
            {
                MessageBox.Show("enter emai");
            }
            else
            {
                string name = txt_studentname.Text;
                string address = txt_studentadress.Text;
                string email = txt_studentemailid.Text;

                student obj = new student();
                obj.studentname = name;
                obj.studentaddress = address;
                obj.studentemailID = email;

                StudentDAL dal = new StudentDAL();
                int ID = dal.AddStudent(obj);
                MessageBox.Show("student add" + ID);

            }

        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_situdentid.Text == string.Empty)
            {
                MessageBox.Show("enter the id");
            }
            else
            {
                int ID = Convert.ToInt32(txt_situdentid.Text);
                StudentDAL dal = new StudentDAL();
                student stu = dal.Find(ID);
                if(stu!=null)
                {
                    txt_studentname.Text = stu.studentname;
                    txt_studentadress.Text = stu.studentaddress;
                    txt_studentemailid.Text = stu.studentemailID;

                }
                else
                {
                    MessageBox.Show("not found");
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txt_situdentid.Text == string.Empty)
            {
                MessageBox.Show("enter student Id");
            }
            
            else if (txt_studentadress.Text == string.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if (txt_studentemailid.Text == string.Empty)
            {
                MessageBox.Show("enter emai");
            }
            else
            {
                int ID = Convert.ToInt32(txt_situdentid.Text);
                
                string address = txt_studentadress.Text;
                string email = txt_studentemailid.Text;
                
                StudentDAL dal = new StudentDAL();
                bool status = dal.Update(ID,address,email);
                if(status)
                {
                    MessageBox.Show("updated");

                }
                else
                {
                    MessageBox.Show("not found");

                }


            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_situdentid.Text == string.Empty)
            {
                MessageBox.Show("ener id");
            }
            else
            {
                int ID = Convert.ToInt32(txt_situdentid.Text);
                StudentDAL dal = new StudentDAL();
                bool status = dal.Delete(ID);
                if (status)
                {
                    MessageBox.Show("deleted");
                }
                else
                {
                    MessageBox.Show("not found");
                }
            }

            }

        private void btn_reset_Click(object sender, EventArgs e)
        {
          txt_studentname.Text = string.Empty;
          txt_studentadress.Text = string.Empty;
          txt_studentemailid.Text = string.Empty;
        }

        private void txt_studentemailid_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_studentadress_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_studentname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_situdentid_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_studentemailid_Click(object sender, EventArgs e)
        {

        }

        private void lbl_studentaddress_Click(object sender, EventArgs e)
        {

        }

        private void lbl_studentname_Click(object sender, EventArgs e)
        {

        }

        private void lbl_studentid_Click(object sender, EventArgs e)
        {

        }
    }
    }
