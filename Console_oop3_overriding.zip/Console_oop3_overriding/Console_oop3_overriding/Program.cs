﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop3_overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("customer name:");
            string Name = Console.ReadLine();
            Console.WriteLine("item qty:");
            int Qty = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("item price:");
            int Price = Convert.ToInt32(Console.ReadLine());

             

           Order obj = null;
            Console.WriteLine("Type of customer");
            String Type = Console.ReadLine();
            if(Type=="Order")
            {
                obj = new Order(Name, Qty, Price);
            }
            else if(Type=="Overseas")
            {
                obj = new Order_Overseas(Name, Qty, Price);
            }

            if (Type != null)
            {
                int id = obj.POredrID;
                Console.WriteLine(" orderid"+id);

                int Amount = obj.GetOrderValue();
                Console.WriteLine("order value"+Amount);

            }

            Console.ReadLine();




        }
    }
}
