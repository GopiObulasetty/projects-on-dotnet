﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop3_overriding
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private int ItemQty;
        private int ItemPrice;
        public static int count = 100;
        public int POredrID{ get { return this.OrderID; } }
        public string PCustomerName{ get { return this.CustomerName; } }
        public int PItemQty { get { return this.ItemQty; } }
        public int PItemPrice { get { return this.ItemPrice; } }

        public Order(string CustomerName, int ItemQty, int ItemPrice)
        {
            Order.count++;
            this.OrderID = Order.count;
            this.CustomerName = CustomerName;
            this.ItemQty = ItemQty;
            this.ItemPrice = ItemPrice;
     
        }

        public virtual int GetOrderValue()

        {
            int Amount = ItemQty * ItemPrice;
            return Amount;
        }


    }
}
