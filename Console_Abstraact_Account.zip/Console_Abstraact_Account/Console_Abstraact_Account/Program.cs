﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Account
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the AccountID");
            int ID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the Custmername");
            string Name = Console.ReadLine();
            Console.WriteLine("enter the Account balance");
            int Balance = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter the Account type");
            string Type = Console.ReadLine();

            Account obj = null;

            if(Type=="Saving")
            {
                obj = new Saving(ID, Name, Balance);
            }
            else if(Type=="Current")
            {
                obj=new Current(ID, Name, Balance);
            }



            if(obj!=null)
                {
                    obj.StopePayment();
               
                int AccBalance = obj.GetBalance();
                Console.WriteLine("balance" + AccBalance);
                Console.WriteLine("enter amount to deposite");
                int Amt = Convert.ToInt32(Console.ReadLine());
                obj.Deposit(Amt);
                AccBalance = obj.GetBalance();
                Console.WriteLine("balance" + AccBalance);
                Console.WriteLine("enter amount to withdraw");
                Amt = Convert.ToInt32(Console.ReadLine());
                obj.WithDraw(Amt);
                AccBalance = obj.GetBalance();
                Console.WriteLine("balance" + AccBalance);


                }

            Console.ReadLine();
        }
    }
}
