﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_MiniProject
{
    public partial class new_transaction : Form
    {
        public new_transaction()
        {
            InitializeComponent();
        }

        private void new_transaction_Load(object sender, EventArgs e)
        {
            cmb_trnsactiontype.Items.Add("withdraw");
            cmb_trnsactiontype.Items.Add("Deposit");

            CustomerDAL dal = new CustomerDAL();
            List<int> x = dal.showOnlyAccounts(Test.cid);

            foreach (int y in x)
            {
                cmb_accountid.Items.Add(y);
            }

        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            cmb_accountid.Text = string.Empty;
            txt_amount.Text = string.Empty;
            cmb_trnsactiontype.Text = string.Empty;
        }

        private void btn_newtrensaction_Click(object sender, EventArgs e)
        {
            if(cmb_accountid.Text==string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else if(txt_amount.Text==string.Empty)
            {
                MessageBox.Show("amount");
            }
            else if(Convert.ToInt32(txt_amount.Text)<0)
            {
                MessageBox.Show("enter the amount greter then 0");
            }
            else if(cmb_trnsactiontype.Text==string.Empty)
            {
                MessageBox.Show("select type");
                
            }
            
            else
            {
                int Id = Convert.ToInt32(cmb_accountid.Text);
                int Amt = Convert.ToInt32(txt_amount.Text);
                string type = cmb_trnsactiontype.Text;

                transaction obj = new transaction();
                obj.AccountID = Id;
                obj.Amount = Amt;
                obj.TransactionType = type;

                CustomerDAL dal = new CustomerDAL();
                int id;
                int balance = dal.accountbalance(Convert.ToInt32(cmb_accountid.Text));
           //     MessageBox.Show(balance.ToString());
                if (obj.TransactionType=="Deposit")
                {
                    int ID = dal.AddTransaction(obj);
                    MessageBox.Show("transaction added" + ID);

                }
                if(obj.TransactionType=="withdraw")
                {
                    if(obj.Amount<balance)
                    {
                        id = dal.AddTransaction(obj);
                        MessageBox.Show("transaction ID" + id);
                    }
                    else
                    {
                        MessageBox.Show("insufficinet balanace" + balance);
                    }
                }


            }
        }
    }
}
