﻿namespace Win_MiniProject
{
    partial class Myaccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_show = new System.Windows.Forms.Button();
            this.dg_showmyaccount = new System.Windows.Forms.DataGridView();
            this.lbl_accountid = new System.Windows.Forms.Label();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dg_showmyaccount)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_show
            // 
            this.btn_show.Location = new System.Drawing.Point(264, 121);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(75, 23);
            this.btn_show.TabIndex = 0;
            this.btn_show.Text = "Show";
            this.btn_show.UseVisualStyleBackColor = true;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // dg_showmyaccount
            // 
            this.dg_showmyaccount.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_showmyaccount.Location = new System.Drawing.Point(119, 187);
            this.dg_showmyaccount.Name = "dg_showmyaccount";
            this.dg_showmyaccount.Size = new System.Drawing.Size(328, 143);
            this.dg_showmyaccount.TabIndex = 1;
            // 
            // lbl_accountid
            // 
            this.lbl_accountid.AutoSize = true;
            this.lbl_accountid.Location = new System.Drawing.Point(179, 68);
            this.lbl_accountid.Name = "lbl_accountid";
            this.lbl_accountid.Size = new System.Drawing.Size(65, 13);
            this.lbl_accountid.TabIndex = 2;
            this.lbl_accountid.Text = "Customer ID";
            // 
            // txt_customerid
            // 
            this.txt_customerid.Location = new System.Drawing.Point(255, 65);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(100, 20);
            this.txt_customerid.TabIndex = 3;
            // 
            // Myaccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(659, 402);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.lbl_accountid);
            this.Controls.Add(this.dg_showmyaccount);
            this.Controls.Add(this.btn_show);
            this.Name = "Myaccount";
            this.Text = "Myaccount";
            this.Load += new System.EventHandler(this.Myaccount_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_showmyaccount)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_show;
        private System.Windows.Forms.DataGridView dg_showmyaccount;
        private System.Windows.Forms.Label lbl_accountid;
        private System.Windows.Forms.TextBox txt_customerid;
    }
}