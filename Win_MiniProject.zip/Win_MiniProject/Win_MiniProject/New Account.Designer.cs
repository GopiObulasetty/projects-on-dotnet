﻿namespace Win_MiniProject
{
    partial class New_Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_customerid = new System.Windows.Forms.Label();
            this.lbl_balance = new System.Windows.Forms.Label();
            this.lbl_accountyoe = new System.Windows.Forms.Label();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            this.txt_balance = new System.Windows.Forms.TextBox();
            this.btn_newaccount = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.cmb_accounttype = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_customerid
            // 
            this.lbl_customerid.AutoSize = true;
            this.lbl_customerid.Location = new System.Drawing.Point(89, 62);
            this.lbl_customerid.Name = "lbl_customerid";
            this.lbl_customerid.Size = new System.Drawing.Size(68, 13);
            this.lbl_customerid.TabIndex = 0;
            this.lbl_customerid.Text = "Customer ID:";
            // 
            // lbl_balance
            // 
            this.lbl_balance.AutoSize = true;
            this.lbl_balance.Location = new System.Drawing.Point(92, 113);
            this.lbl_balance.Name = "lbl_balance";
            this.lbl_balance.Size = new System.Drawing.Size(40, 13);
            this.lbl_balance.TabIndex = 1;
            this.lbl_balance.Text = "Blance";
            // 
            // lbl_accountyoe
            // 
            this.lbl_accountyoe.AutoSize = true;
            this.lbl_accountyoe.Location = new System.Drawing.Point(89, 166);
            this.lbl_accountyoe.Name = "lbl_accountyoe";
            this.lbl_accountyoe.Size = new System.Drawing.Size(74, 13);
            this.lbl_accountyoe.TabIndex = 2;
            this.lbl_accountyoe.Text = "Account Type";
            // 
            // txt_customerid
            // 
            this.txt_customerid.Location = new System.Drawing.Point(186, 59);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(100, 20);
            this.txt_customerid.TabIndex = 3;
            // 
            // txt_balance
            // 
            this.txt_balance.Location = new System.Drawing.Point(186, 110);
            this.txt_balance.Name = "txt_balance";
            this.txt_balance.Size = new System.Drawing.Size(100, 20);
            this.txt_balance.TabIndex = 4;
            // 
            // btn_newaccount
            // 
            this.btn_newaccount.Location = new System.Drawing.Point(82, 224);
            this.btn_newaccount.Name = "btn_newaccount";
            this.btn_newaccount.Size = new System.Drawing.Size(99, 23);
            this.btn_newaccount.TabIndex = 6;
            this.btn_newaccount.Text = "New Account";
            this.btn_newaccount.UseVisualStyleBackColor = true;
            this.btn_newaccount.Click += new System.EventHandler(this.btn_newaccount_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(205, 224);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(81, 23);
            this.btn_reset.TabIndex = 7;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // cmb_accounttype
            // 
            this.cmb_accounttype.FormattingEnabled = true;
            this.cmb_accounttype.Location = new System.Drawing.Point(189, 162);
            this.cmb_accounttype.Name = "cmb_accounttype";
            this.cmb_accounttype.Size = new System.Drawing.Size(97, 21);
            this.cmb_accounttype.TabIndex = 8;
            // 
            // New_Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(565, 463);
            this.Controls.Add(this.cmb_accounttype);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newaccount);
            this.Controls.Add(this.txt_balance);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.lbl_accountyoe);
            this.Controls.Add(this.lbl_balance);
            this.Controls.Add(this.lbl_customerid);
            this.Name = "New_Account";
            this.Text = "New_Account";
            this.Load += new System.EventHandler(this.New_Account_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_customerid;
        private System.Windows.Forms.Label lbl_balance;
        private System.Windows.Forms.Label lbl_accountyoe;
        private System.Windows.Forms.TextBox txt_customerid;
        private System.Windows.Forms.TextBox txt_balance;
        private System.Windows.Forms.Button btn_newaccount;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.ComboBox cmb_accounttype;
    }
}