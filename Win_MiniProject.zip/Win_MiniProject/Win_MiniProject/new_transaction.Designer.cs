﻿namespace Win_MiniProject
{
    partial class new_transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_newtrensaction = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.lbl_accountid = new System.Windows.Forms.Label();
            this.lbl_amount = new System.Windows.Forms.Label();
            this.lbl_transactiontype = new System.Windows.Forms.Label();
            this.txt_amount = new System.Windows.Forms.TextBox();
            this.cmb_trnsactiontype = new System.Windows.Forms.ComboBox();
            this.cmb_accountid = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btn_newtrensaction
            // 
            this.btn_newtrensaction.Location = new System.Drawing.Point(125, 254);
            this.btn_newtrensaction.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_newtrensaction.Name = "btn_newtrensaction";
            this.btn_newtrensaction.Size = new System.Drawing.Size(155, 28);
            this.btn_newtrensaction.TabIndex = 0;
            this.btn_newtrensaction.Text = "New Transaction";
            this.btn_newtrensaction.UseVisualStyleBackColor = true;
            this.btn_newtrensaction.Click += new System.EventHandler(this.btn_newtrensaction_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(327, 254);
            this.btn_reset.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(100, 28);
            this.btn_reset.TabIndex = 1;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // lbl_accountid
            // 
            this.lbl_accountid.AutoSize = true;
            this.lbl_accountid.Location = new System.Drawing.Point(129, 74);
            this.lbl_accountid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_accountid.Name = "lbl_accountid";
            this.lbl_accountid.Size = new System.Drawing.Size(76, 17);
            this.lbl_accountid.TabIndex = 2;
            this.lbl_accountid.Text = "Account ID";
            // 
            // lbl_amount
            // 
            this.lbl_amount.AutoSize = true;
            this.lbl_amount.Location = new System.Drawing.Point(133, 118);
            this.lbl_amount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_amount.Name = "lbl_amount";
            this.lbl_amount.Size = new System.Drawing.Size(56, 17);
            this.lbl_amount.TabIndex = 3;
            this.lbl_amount.Text = "Amount";
            // 
            // lbl_transactiontype
            // 
            this.lbl_transactiontype.AutoSize = true;
            this.lbl_transactiontype.Location = new System.Drawing.Point(121, 164);
            this.lbl_transactiontype.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_transactiontype.Name = "lbl_transactiontype";
            this.lbl_transactiontype.Size = new System.Drawing.Size(119, 17);
            this.lbl_transactiontype.TabIndex = 4;
            this.lbl_transactiontype.Text = "Transaction Type";
            // 
            // txt_amount
            // 
            this.txt_amount.Location = new System.Drawing.Point(252, 116);
            this.txt_amount.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_amount.Name = "txt_amount";
            this.txt_amount.Size = new System.Drawing.Size(132, 23);
            this.txt_amount.TabIndex = 6;
            // 
            // cmb_trnsactiontype
            // 
            this.cmb_trnsactiontype.FormattingEnabled = true;
            this.cmb_trnsactiontype.Location = new System.Drawing.Point(255, 165);
            this.cmb_trnsactiontype.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmb_trnsactiontype.Name = "cmb_trnsactiontype";
            this.cmb_trnsactiontype.Size = new System.Drawing.Size(131, 24);
            this.cmb_trnsactiontype.TabIndex = 7;
            // 
            // cmb_accountid
            // 
            this.cmb_accountid.FormattingEnabled = true;
            this.cmb_accountid.Location = new System.Drawing.Point(251, 74);
            this.cmb_accountid.Name = "cmb_accountid";
            this.cmb_accountid.Size = new System.Drawing.Size(135, 24);
            this.cmb_accountid.TabIndex = 8;
            // 
            // new_transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(708, 510);
            this.Controls.Add(this.cmb_accountid);
            this.Controls.Add(this.cmb_trnsactiontype);
            this.Controls.Add(this.txt_amount);
            this.Controls.Add(this.lbl_transactiontype);
            this.Controls.Add(this.lbl_amount);
            this.Controls.Add(this.lbl_accountid);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newtrensaction);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "new_transaction";
            this.Text = "new_transaction";
            this.Load += new System.EventHandler(this.new_transaction_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_newtrensaction;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Label lbl_accountid;
        private System.Windows.Forms.Label lbl_amount;
        private System.Windows.Forms.Label lbl_transactiontype;
        private System.Windows.Forms.TextBox txt_amount;
        private System.Windows.Forms.ComboBox cmb_trnsactiontype;
        private System.Windows.Forms.ComboBox cmb_accountid;
    }
}