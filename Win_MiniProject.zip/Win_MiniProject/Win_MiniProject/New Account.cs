﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_MiniProject
{
    public partial class New_Account : Form
    {
        public New_Account()
        {
            InitializeComponent();
        }

        private void New_Account_Load(object sender, EventArgs e)
        {
            cmb_accounttype.Items.Add("Saving");
            cmb_accounttype.Items.Add("Current");
            txt_customerid.Text = Test.cid.ToString();
            txt_customerid.Enabled =false;
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_customerid.Text = string.Empty;
            txt_balance.Text = string.Empty;
            cmb_accounttype.Text = string.Empty;
        }

        private void btn_newaccount_Click(object sender, EventArgs e)
        {
            if(txt_customerid.Text==string.Empty)
            {
                MessageBox.Show("enter the id");
            }
            else if(txt_balance.Text==string.Empty)
            {
                MessageBox.Show("enter balance");
            }
            else if(Convert.ToInt32(txt_balance.Text)<0)
            {
                MessageBox.Show("the number should be positive");
            }
            else
            {
                int ID =Convert.ToInt32( txt_customerid.Text);
                int Bal = Convert.ToInt32(txt_balance.Text);
                string type = cmb_accounttype.Text;
                Account obj = new Account();
                obj.CustomerID = ID;
                obj.AccountBalance = Bal;
                obj.AccountType = type;

                CustomerDAL dal = new CustomerDAL();
                int id=dal.AddAccount(obj);
                MessageBox.Show("account add" + id);



            }
        }
    }
}
