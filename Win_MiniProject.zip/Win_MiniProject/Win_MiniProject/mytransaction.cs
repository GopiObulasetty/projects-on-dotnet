﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_MiniProject
{
    public partial class mytransaction : Form
    {
        public mytransaction()
        {
            InitializeComponent();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            if(cmb_accountid.Text==string.Empty)
            {
                MessageBox.Show("id");
            }
            else
            {
                CustomerDAL dal = new CustomerDAL();
                List<transaction> list = dal.showtransaction(Convert.ToInt32(cmb_accountid.Text));
                dg_showtransactions.DataSource = list;
            }
        }

        private void mytransaction_Load(object sender, EventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            List<int> y = dal.showOnlyAccounts(Test.cid);
            foreach (int x in y)
            {
                cmb_accountid.Items.Add(x);
            }
        }
    }
}
