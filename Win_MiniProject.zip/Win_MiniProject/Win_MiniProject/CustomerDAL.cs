﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace Win_MiniProject
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);


        public int AddCustomer(Customer cust)
        {
            SqlCommand com_insert_customer = new SqlCommand("proc_addcustomer", con);

            com_insert_customer.Parameters.AddWithValue("@name", cust.CustomerName);
            com_insert_customer.Parameters.AddWithValue("@email", cust.CustomerEmail);
            com_insert_customer.Parameters.AddWithValue("@mobileno", cust.MobileNumber);
            com_insert_customer.Parameters.AddWithValue("@gender", cust.CustomerGender);
            com_insert_customer.Parameters.AddWithValue("@password", cust.CustomerPassword);
            com_insert_customer.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_insert_customer.Parameters.Add(retdata);

            con.Open();
            com_insert_customer.ExecuteNonQuery();
            con.Close();
            int ID = Convert.ToInt32(retdata.Value);
            return ID;
        }

        public bool Login(int ID,string password)
        {
            SqlCommand com_login = new SqlCommand("proc_login", con);
            com_login.Parameters.AddWithValue("@id", ID);
            com_login.Parameters.AddWithValue("@password", password);
            com_login.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_login.Parameters.Add(retdata);
            con.Open();
            com_login.ExecuteNonQuery();
            int count = Convert.ToInt32(retdata.Value);
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;
            }

        

        }


        public int AddAccount(Account acc)
        {
            SqlCommand com_insert_account = new SqlCommand("proc_addaccount", con);

            com_insert_account.Parameters.AddWithValue("@customerid", acc.CustomerID);
            com_insert_account.Parameters.AddWithValue("@accounttype", acc.AccountType);

            com_insert_account.Parameters.AddWithValue("@balance", acc.AccountBalance);
            com_insert_account.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_insert_account.Parameters.Add(retdata);

            con.Open();
            com_insert_account.ExecuteNonQuery();
            con.Close();
            int ID = Convert.ToInt32(retdata.Value);
            return ID;
        }


        public int AddTransaction(transaction trns)
        {
            SqlCommand com_insert_trnsaction = new SqlCommand("proc_addtransaction", con);

            com_insert_trnsaction.Parameters.AddWithValue("@accountid", trns.AccountID);
            com_insert_trnsaction.Parameters.AddWithValue("@amount", trns.Amount);

            com_insert_trnsaction.Parameters.AddWithValue("@transactiontype", trns.TransactionType);
            com_insert_trnsaction.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_insert_trnsaction.Parameters.Add(retdata);

            con.Open();
            com_insert_trnsaction.ExecuteNonQuery();
            con.Close();
            int ID = Convert.ToInt32(retdata.Value);
            return ID;
        }

        public List<Account> showAccounts(int cid)
        {
            SqlCommand com_ac_show = new SqlCommand("proc_showaccountdetails", con);
            com_ac_show.Parameters.AddWithValue("@id", cid);
            com_ac_show.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_ac_show.ExecuteReader();

            List<Account> culist = new List<Account>();
            while (dr.Read())
            {
                Account ac = new Account();
                ac.AccountID = dr.GetInt32(0);
                ac.CustomerID = dr.GetInt32(1);
                ac.AccountBalance = dr.GetInt32(2);
                ac.AccountOD = dr.GetDateTime(3);

                ac.AccountType = dr.GetString(4);


                culist.Add(ac);
            }
            con.Close();
            return culist;
        }

        public int accountbalance(int ID)
        {
            SqlCommand com_bal = new SqlCommand("proc_accountbalance", con);
            com_bal.Parameters.AddWithValue("@id", ID);
            com_bal.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_bal.Parameters.Add(retdata);
            con.Open();
            com_bal.ExecuteNonQuery();
            con.Close();
            int balance = Convert.ToInt32(retdata.Value);
            return balance;



        }



        public List<transaction> showtransaction(int ID)
        {
            try
            { 

            SqlCommand com_trans_insert= new SqlCommand("proc_showtransactiondetails", con);
            com_trans_insert.Parameters.AddWithValue("@ID", ID);
            com_trans_insert.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = com_trans_insert.ExecuteReader();
            List<transaction> trnaslist = new List<transaction>();
            while (dr.Read())
            {
                transaction obj = new transaction();
                obj.TransactionID = dr.GetInt32(0);
                obj.AccountID = dr.GetInt32(1);
                obj.Amount = dr.GetInt32(2);
                obj.TransactionType = dr.GetString(3);

                obj.TransactonDate = dr.GetDateTime(4);

                trnaslist.Add(obj);
            }
            con.Close();
            return trnaslist;
            }
            finally
            {
            if(con.State==ConnectionState.Open)
              {
                con.Close();
              }
            }
        }

        public List<int> showOnlyAccounts(int cid)
        {
           try
            { 
                SqlCommand com_ac_show = new SqlCommand("show_account", con);
                com_ac_show.Parameters.AddWithValue("@cid", cid);
                com_ac_show.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = com_ac_show.ExecuteReader();

                List<int> culist = new List<int>();
                while (dr.Read())
                {

                    culist.Add(dr.GetInt32(0));
                }
                con.Close();
                return culist;
            }
            finally
            {
                if(con.State==ConnectionState.Open)
                {
                    con.Close();
                }
            }
               }
            }



    }
    
