﻿namespace Win_MiniProject
{
    partial class mytransaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_show = new System.Windows.Forms.Button();
            this.lbl_accountid = new System.Windows.Forms.Label();
            this.dg_showtransactions = new System.Windows.Forms.DataGridView();
            this.cmb_accountid = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dg_showtransactions)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_show
            // 
            this.btn_show.Location = new System.Drawing.Point(213, 116);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(139, 23);
            this.btn_show.TabIndex = 0;
            this.btn_show.Text = "Show Transaction";
            this.btn_show.UseVisualStyleBackColor = true;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // lbl_accountid
            // 
            this.lbl_accountid.AutoSize = true;
            this.lbl_accountid.Location = new System.Drawing.Point(176, 63);
            this.lbl_accountid.Name = "lbl_accountid";
            this.lbl_accountid.Size = new System.Drawing.Size(61, 13);
            this.lbl_accountid.TabIndex = 1;
            this.lbl_accountid.Text = "Account ID";
            // 
            // dg_showtransactions
            // 
            this.dg_showtransactions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_showtransactions.Location = new System.Drawing.Point(111, 179);
            this.dg_showtransactions.Name = "dg_showtransactions";
            this.dg_showtransactions.Size = new System.Drawing.Size(328, 143);
            this.dg_showtransactions.TabIndex = 3;
            // 
            // cmb_accountid
            // 
            this.cmb_accountid.FormattingEnabled = true;
            this.cmb_accountid.Location = new System.Drawing.Point(256, 60);
            this.cmb_accountid.Name = "cmb_accountid";
            this.cmb_accountid.Size = new System.Drawing.Size(121, 21);
            this.cmb_accountid.TabIndex = 4;
            // 
            // mytransaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(554, 367);
            this.Controls.Add(this.cmb_accountid);
            this.Controls.Add(this.dg_showtransactions);
            this.Controls.Add(this.lbl_accountid);
            this.Controls.Add(this.btn_show);
            this.Name = "mytransaction";
            this.Text = "mytransaction";
            this.Load += new System.EventHandler(this.mytransaction_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_showtransactions)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_show;
        private System.Windows.Forms.Label lbl_accountid;
        private System.Windows.Forms.DataGridView dg_showtransactions;
        private System.Windows.Forms.ComboBox cmb_accountid;
    }
}