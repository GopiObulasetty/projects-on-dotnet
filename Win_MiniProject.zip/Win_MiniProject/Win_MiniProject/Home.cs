﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_MiniProject
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void btn_newaccount_Click(object sender, EventArgs e)
        {
            New_Account a = new New_Account();
            a.Show();
        }

        private void btn_myaccount_Click(object sender, EventArgs e)
        {
            Myaccount a = new Myaccount();
            a.Show();
        }

        private void btn_newtransaction_Click(object sender, EventArgs e)
        {
            new_transaction a = new new_transaction();
            a.Show();
        }

        private void btn_mytransaction_Click(object sender, EventArgs e)
        {
            mytransaction a = new mytransaction();
            a.Show();
        }
    }
}
