﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_MiniProject
{
    public partial class Myaccount : Form
    {
        public Myaccount()
        {
            InitializeComponent();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            if(txt_customerid.Text==string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                CustomerDAL dal = new CustomerDAL();
                List<Account> list = dal.showAccounts(Convert.ToInt32(txt_customerid.Text));
                dg_showmyaccount.DataSource = list;

            }
        }

        private void Myaccount_Load(object sender, EventArgs e)
        {
            txt_customerid.Text = Test.cid.ToString();
            txt_customerid.Enabled = false;

        }
    }
}
