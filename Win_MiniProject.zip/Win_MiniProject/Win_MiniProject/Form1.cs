﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_MiniProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btn_nreset_Click(object sender, EventArgs e)
        {
            txt_customername.Text = string.Empty;
            txt_email.Text = string.Empty;
            txt_mobilenumber.Text = string.Empty;
            txt_npassword.Text = string.Empty;
        }

        private void btn_newcustomer_Click(object sender, EventArgs e)
        {
            if (txt_customername.Text == string.Empty)
            {
                MessageBox.Show("enter name");
            }
            else if (txt_email.Text == string.Empty) 
            {
                MessageBox.Show("enter email");
            }
            else if(txt_mobilenumber.Text==string.Empty)
            {
                MessageBox.Show("enter mo.no");
            }
            else if(txt_npassword.Text==string.Empty)
            {
                MessageBox.Show("enter password ");
            }
            else
            {
                string name = txt_customername.Text;
                string email = txt_email.Text;
                string mobileno = txt_mobilenumber.Text;
                string gender = cmb_gender.Text;
                string password = txt_npassword.Text;

                Customer obj = new Customer();
                obj.CustomerName = name;
                obj.CustomerEmail = email;
                obj.MobileNumber = mobileno;
                obj.CustomerGender = gender;
                obj.CustomerPassword = password;

                CustomerDAL dal = new CustomerDAL();
                int id = dal.AddCustomer(obj);
                MessageBox.Show("customer add" + id);


            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmb_gender.Items.Add("Male");
            cmb_gender.Items.Add("Female");
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if(txt_customerid.Text==string.Empty)
            {
                MessageBox.Show("enter the id");
            }
            else if(txt_password.Text==string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {
                int ID = Convert.ToInt32(txt_customerid.Text);
                string password = txt_password.Text;


                CustomerDAL dal = new CustomerDAL();
                bool status = dal.Login(ID, password);
                if(status)
                {
                    MessageBox.Show("valid user");
                    Test.cid = ID;
                    Home a = new Home();
                    a.Show();
                }
                else
                {
                    MessageBox.Show("invalid user");
                }

            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_customerid.Text = string.Empty;
            txt_password.Text = string.Empty;
        }
    }
}
