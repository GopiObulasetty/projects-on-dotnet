﻿namespace Win_MiniProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_login = new System.Windows.Forms.Button();
            this.lbl_customerid = new System.Windows.Forms.Label();
            this.lbl_password = new System.Windows.Forms.Label();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.txt_mobilenumber = new System.Windows.Forms.TextBox();
            this.btn_newcustomer = new System.Windows.Forms.Button();
            this.btn_nreset = new System.Windows.Forms.Button();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_Customeremail = new System.Windows.Forms.Label();
            this.lbl_mobilenumber = new System.Windows.Forms.Label();
            this.lbl_gender = new System.Windows.Forms.Label();
            this.lbl_npassword = new System.Windows.Forms.Label();
            this.txt_npassword = new System.Windows.Forms.TextBox();
            this.cmb_gender = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(154, 155);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_reset.TabIndex = 0;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(46, 155);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(75, 23);
            this.btn_login.TabIndex = 1;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // lbl_customerid
            // 
            this.lbl_customerid.AutoSize = true;
            this.lbl_customerid.Location = new System.Drawing.Point(44, 44);
            this.lbl_customerid.Name = "lbl_customerid";
            this.lbl_customerid.Size = new System.Drawing.Size(65, 13);
            this.lbl_customerid.TabIndex = 2;
            this.lbl_customerid.Text = "Customer ID";
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Location = new System.Drawing.Point(43, 94);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(53, 13);
            this.lbl_password.TabIndex = 3;
            this.lbl_password.Text = "Password";
            // 
            // txt_customerid
            // 
            this.txt_customerid.Location = new System.Drawing.Point(129, 41);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(100, 20);
            this.txt_customerid.TabIndex = 4;
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(129, 87);
            this.txt_password.Name = "txt_password";
            this.txt_password.PasswordChar = '*';
            this.txt_password.Size = new System.Drawing.Size(100, 20);
            this.txt_password.TabIndex = 5;
            // 
            // txt_customername
            // 
            this.txt_customername.Location = new System.Drawing.Point(454, 33);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(100, 20);
            this.txt_customername.TabIndex = 6;
            // 
            // txt_email
            // 
            this.txt_email.Location = new System.Drawing.Point(454, 80);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(100, 20);
            this.txt_email.TabIndex = 7;
            // 
            // txt_mobilenumber
            // 
            this.txt_mobilenumber.Location = new System.Drawing.Point(454, 126);
            this.txt_mobilenumber.Name = "txt_mobilenumber";
            this.txt_mobilenumber.Size = new System.Drawing.Size(100, 20);
            this.txt_mobilenumber.TabIndex = 8;
            // 
            // btn_newcustomer
            // 
            this.btn_newcustomer.Location = new System.Drawing.Point(348, 269);
            this.btn_newcustomer.Name = "btn_newcustomer";
            this.btn_newcustomer.Size = new System.Drawing.Size(90, 23);
            this.btn_newcustomer.TabIndex = 10;
            this.btn_newcustomer.Text = "New Customer";
            this.btn_newcustomer.UseVisualStyleBackColor = true;
            this.btn_newcustomer.Click += new System.EventHandler(this.btn_newcustomer_Click);
            // 
            // btn_nreset
            // 
            this.btn_nreset.Location = new System.Drawing.Point(494, 269);
            this.btn_nreset.Name = "btn_nreset";
            this.btn_nreset.Size = new System.Drawing.Size(75, 23);
            this.btn_nreset.TabIndex = 11;
            this.btn_nreset.Text = "Reset";
            this.btn_nreset.UseVisualStyleBackColor = true;
            this.btn_nreset.Click += new System.EventHandler(this.btn_nreset_Click);
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Location = new System.Drawing.Point(345, 36);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(82, 13);
            this.lbl_customername.TabIndex = 12;
            this.lbl_customername.Text = "Customer Name";
            // 
            // lbl_Customeremail
            // 
            this.lbl_Customeremail.AutoSize = true;
            this.lbl_Customeremail.Location = new System.Drawing.Point(345, 87);
            this.lbl_Customeremail.Name = "lbl_Customeremail";
            this.lbl_Customeremail.Size = new System.Drawing.Size(93, 13);
            this.lbl_Customeremail.TabIndex = 13;
            this.lbl_Customeremail.Text = "Customer Email ID";
            // 
            // lbl_mobilenumber
            // 
            this.lbl_mobilenumber.AutoSize = true;
            this.lbl_mobilenumber.Location = new System.Drawing.Point(346, 133);
            this.lbl_mobilenumber.Name = "lbl_mobilenumber";
            this.lbl_mobilenumber.Size = new System.Drawing.Size(78, 13);
            this.lbl_mobilenumber.TabIndex = 14;
            this.lbl_mobilenumber.Text = "Mobile Number";
            // 
            // lbl_gender
            // 
            this.lbl_gender.AutoSize = true;
            this.lbl_gender.Location = new System.Drawing.Point(346, 170);
            this.lbl_gender.Name = "lbl_gender";
            this.lbl_gender.Size = new System.Drawing.Size(42, 13);
            this.lbl_gender.TabIndex = 15;
            this.lbl_gender.Text = "Gender";
            this.lbl_gender.Click += new System.EventHandler(this.label4_Click);
            // 
            // lbl_npassword
            // 
            this.lbl_npassword.AutoSize = true;
            this.lbl_npassword.Location = new System.Drawing.Point(346, 214);
            this.lbl_npassword.Name = "lbl_npassword";
            this.lbl_npassword.Size = new System.Drawing.Size(53, 13);
            this.lbl_npassword.TabIndex = 16;
            this.lbl_npassword.Text = "Password";
            // 
            // txt_npassword
            // 
            this.txt_npassword.Location = new System.Drawing.Point(454, 207);
            this.txt_npassword.Name = "txt_npassword";
            this.txt_npassword.Size = new System.Drawing.Size(97, 20);
            this.txt_npassword.TabIndex = 17;
            // 
            // cmb_gender
            // 
            this.cmb_gender.FormattingEnabled = true;
            this.cmb_gender.Location = new System.Drawing.Point(454, 167);
            this.cmb_gender.Name = "cmb_gender";
            this.cmb_gender.Size = new System.Drawing.Size(97, 21);
            this.cmb_gender.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(642, 426);
            this.Controls.Add(this.cmb_gender);
            this.Controls.Add(this.txt_npassword);
            this.Controls.Add(this.lbl_npassword);
            this.Controls.Add(this.lbl_gender);
            this.Controls.Add(this.lbl_mobilenumber);
            this.Controls.Add(this.lbl_Customeremail);
            this.Controls.Add(this.lbl_customername);
            this.Controls.Add(this.btn_nreset);
            this.Controls.Add(this.btn_newcustomer);
            this.Controls.Add(this.txt_mobilenumber);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.lbl_customerid);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.btn_reset);
            this.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Label lbl_customerid;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.TextBox txt_customerid;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.TextBox txt_mobilenumber;
        private System.Windows.Forms.Button btn_newcustomer;
        private System.Windows.Forms.Button btn_nreset;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_Customeremail;
        private System.Windows.Forms.Label lbl_mobilenumber;
        private System.Windows.Forms.Label lbl_gender;
        private System.Windows.Forms.Label lbl_npassword;
        private System.Windows.Forms.TextBox txt_npassword;
        private System.Windows.Forms.ComboBox cmb_gender;
    }
}

