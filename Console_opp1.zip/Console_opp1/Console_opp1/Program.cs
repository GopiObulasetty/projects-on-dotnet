﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_opp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter Account ID:");
            int AccID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter Customer name:");
            string Name = Console.ReadLine();
            Console.WriteLine("enter Account Balance:");
            int Balance= Convert.ToInt32(Console.ReadLine());

            Account obj = new Account(AccID, Name, Balance);

            int NewBalance = obj.GetBalance();
            Console.WriteLine("Account Balance:" + NewBalance);

            Console.WriteLine("enter the Amount to with draw:");
            int Amt= Convert.ToInt32(Console.ReadLine());

            obj.Withraw(Amt);

            NewBalance = obj.GetBalance();
            Console.Write("Account Balance:" + NewBalance);
            Console.WriteLine("enter the amount to deposit:");
            Amt= Convert.ToInt32(Console.ReadLine());
            obj.Deposit(Amt);

            NewBalance = obj.GetBalance();
            Console.WriteLine("Account Balance:" + NewBalance);


            /* Console.WriteLine("enter the customer ID:");
             int id = Convert.ToInt32(Console.ReadLine());
             Console.WriteLine("enter the customer name:");
             string name = Console.ReadLine();
             Console.WriteLine("enter the customercity:");
             string city= Console.ReadLine();

             Customer obj = new Customer(id, name, city);
             string Details = obj.GetDetails();
             Console.WriteLine(Details);*/
            Console.ReadLine();
        }
    }
}
