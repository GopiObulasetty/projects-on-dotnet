﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_PropertiesHotel
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private string ItemName;
        private int ItemPrice;
        private int ItemQty;    

        public int POrderID
        {
            get
            {
                return this.OrderID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public string PItemName
        {
            get
            {
                return this.ItemName;
            }
            set
            {
                 this.ItemName = value;
            }
        }
        public int PItemPrice
        {
            get
            {
                return this.ItemPrice;
            }
            set
            {
                 this.ItemPrice = value;
            }
        }
        public int PItemQty
        {
            get
            {
                return this.ItemQty;
            }
            set
            {
                this.ItemQty = value;
            }
        }
        static private int Count = 100;
        public Order(int OrederID, string CustmerName, string ItemName, int ItemPrice, int ItemQty)
        {
            Order.Count++;
            
            this.OrderID = Order.Count;
            this.CustomerName = CustmerName;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.ItemQty = ItemQty;
        }
        public int Amount()
        {
            return this.ItemPrice * ItemQty;
        }



       
      


    }
}
