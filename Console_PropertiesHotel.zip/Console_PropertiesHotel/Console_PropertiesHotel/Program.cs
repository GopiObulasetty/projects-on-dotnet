﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_PropertiesHotel
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the orderId");
            int OrderID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("customer name");
            string CustName = Console.ReadLine();
            Console.WriteLine("Item name");
            string ItemName = Console.ReadLine();
            Console.WriteLine("enter the price");
            int ItemPrice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("quantity");
            int qty = Convert.ToInt32(Console.ReadLine());


            Order obj = new Order(OrderID, CustName, ItemName, ItemPrice, qty);

            int sid = obj.POrderID;
            string sCname = obj.PCustomerName;
            string siname = obj.PItemName;
            int sprice = obj.PItemPrice;
            int sqty = obj.PItemQty;
            Console.WriteLine("Amount is");
            int Amt = obj.Amount();
            Console.WriteLine("Amount is"+Amt)
            Console.WriteLine(sid + "" + sCname + "" + siname + "" + sprice + "" + sqty+""+Amt);
            Console.ReadLine();


        }
    }
}
