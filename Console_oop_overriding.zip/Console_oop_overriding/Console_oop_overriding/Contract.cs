﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_overriding
{
    class Contract:Employee
    {
        public Contract(int EmployeeID,string EmployeeName, int EmployeeSalary) :
            base(EmployeeID,EmployeeName, EmployeeSalary)
        {

        }
        public override int GetSalary(int Days )
        {
            int Salary = (this.PEmployeeSalary / 30 * Days);
            return Salary;
        }
    }
}
