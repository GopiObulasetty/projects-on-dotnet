﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_overriding
{
    class Training:Employee
    {
        public Training(int EmployeeID, string EmployeeName, int EmployeeSalary) 
            :base(EmployeeID, EmployeeName, EmployeeSalary)
        {

        }
        public override int GetSalary(int Days)
        {
            return 10000;
        }
    }
}
