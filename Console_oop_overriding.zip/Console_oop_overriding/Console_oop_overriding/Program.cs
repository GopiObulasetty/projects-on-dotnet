﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the  empID");
            int EmpID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("emp name");
            string EmpName = Console.ReadLine();
            Console.WriteLine("enter the Emp salary");
            int Salary = Convert.ToInt32(Console.ReadLine());

            Employee obj = null;
            Console.WriteLine("enter THE Type employee");
            string Type = Console.ReadLine();
            if(Type=="Contract")
            {
                obj = new Contract(EmpID, EmpName, Salary);
            }
            else if(Type=="Training")
            {
                obj = new Training(EmpID, EmpName, Salary);
            }
            string Work = obj.GetWork();
            Console.WriteLine(Work);

            Console.WriteLine("enter the no days");
            int Days= Convert.ToInt32(Console.ReadLine());

            int CurrentMOnthSAlary = obj.GetSalary(Days);
            Console.WriteLine("salary" + CurrentMOnthSAlary);
            Console.ReadLine();
        }
    }
}
