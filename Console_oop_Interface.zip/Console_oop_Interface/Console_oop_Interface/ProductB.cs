﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_Interface
{
    class ProductB :IProductTransport
    {
        private int PID;
        private string PName;

        public ProductB(int PID, string PName)
        {
            this.PID = PID;
            this.PName = PName;
        }

        public int GetPrice()
        {
            return 20000;
        }
        public string GetDetails()
        {
            return this.PID + "" + this.PName;
        }
        public void Start()
        {

        }
        public void Stop()
        {

        }

        public string GetAddress()
        {
            return "ABC,Chenni";
        }
    }
}
