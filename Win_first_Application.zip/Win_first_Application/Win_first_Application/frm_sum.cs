﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_first_Application
{
    public partial class frm_sum : Form
    {
        public frm_sum()
        {
            InitializeComponent();
        }

        private void lbl_firstno_Click(object sender, EventArgs e)
        {

        }

        private void lbl_SecondNo_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void frm_sum_Load(object sender, EventArgs e)
        {

        }

        private void txt_SecondNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_Sum_Click(object sender, EventArgs e)
        {
            if(txt_Number1.Text==string.Empty)
            {
                MessageBox.Show("enter Number 1");
            }
            else if(txt_Number2.Text==string.Empty)
            {
                MessageBox.Show("enter the number2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_Number1.Text);
                int num2 = Convert.ToInt32(txt_Number2.Text);
                int total = num1 + num2;
                MessageBox.Show("Total" + total);
            }
        }
    }
}
