﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_first_Application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           if( txt_loginid.Text==string.Empty)
            {
                MessageBox.Show("Enter Loin ID");
            }
           else if(txt_password.Text==string.Empty)
                {
                MessageBox.Show("Enter password");
            }
           else
            {
                string loginid = txt_loginid.Text;
                string password = txt_password.Text;
                if(loginid=="admin@gmail.com"&&password=="pass@123")
                {
                    MessageBox.Show("valid user");
                    frm_sum obj = new frm_sum();
                    obj.Show();
                }
                else
                {
                    MessageBox.Show("invalid user");
                }
            }
        }

        private void lbl_Password_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
