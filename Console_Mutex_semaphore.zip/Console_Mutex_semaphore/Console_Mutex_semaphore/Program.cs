﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace Console_Mutex_semaphore
{
    class Program
    {
        static void Main(string[] args)
        {
            bool status;
            //    Mutex m = new Mutex(false, "XYZ", out status);
            //   m.ReleaseMutex();

            Semaphore sm = new Semaphore(3, 4);
            Task t1 = Task.Run(() =>
            {
                // m.WaitOne();
                sm.WaitOne();
                Console.WriteLine("task1 started");
                Thread.Sleep(10000);
                Console.WriteLine("task1 completed");
                sm.Release();
               // m.ReleaseMutex();
            });

            Task t2 = Task.Run(() =>
            {
                // m.WaitOne();
                sm.WaitOne();
                Console.WriteLine("task2 started");
                Thread.Sleep(10000);
                Console.WriteLine("task2 completed");
                sm.Release();
              //  m.ReleaseMutex();
            });


            Task t3 = Task.Run(() =>
            {
                // m.WaitOne();
                sm.WaitOne();
                Console.WriteLine("task3 started");
                Thread.Sleep(10000);
                Console.WriteLine("task3 completed");
                sm.Release();
                //  m.ReleaseMutex();
            });


            Task t4 = Task.Run(() =>
            {
                // m.WaitOne();
                sm.WaitOne();
                Console.WriteLine("task4 started");
                Thread.Sleep(10000);
                Console.WriteLine("task4 completed");
                sm.Release();
                //  m.ReleaseMutex();
            });
            Console.ReadLine();
        }
    }
}
