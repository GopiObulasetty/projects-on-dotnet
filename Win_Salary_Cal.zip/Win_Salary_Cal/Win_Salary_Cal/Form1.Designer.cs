﻿namespace Win_Salary_Cal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_days = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_days = new System.Windows.Forms.TextBox();
            this.txt_perdaysalary = new System.Windows.Forms.TextBox();
            this.btn_getsalary = new System.Windows.Forms.Button();
            this.lbl_salary = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_days
            // 
            this.lbl_days.AutoSize = true;
            this.lbl_days.Location = new System.Drawing.Point(30, 34);
            this.lbl_days.Name = "lbl_days";
            this.lbl_days.Size = new System.Drawing.Size(31, 13);
            this.lbl_days.TabIndex = 0;
            this.lbl_days.Text = "Days";
            this.lbl_days.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Per Day Salary";
            // 
            // txt_days
            // 
            this.txt_days.Location = new System.Drawing.Point(120, 34);
            this.txt_days.Name = "txt_days";
            this.txt_days.Size = new System.Drawing.Size(100, 20);
            this.txt_days.TabIndex = 2;
            // 
            // txt_perdaysalary
            // 
            this.txt_perdaysalary.Location = new System.Drawing.Point(117, 81);
            this.txt_perdaysalary.Name = "txt_perdaysalary";
            this.txt_perdaysalary.Size = new System.Drawing.Size(100, 20);
            this.txt_perdaysalary.TabIndex = 3;
            // 
            // btn_getsalary
            // 
            this.btn_getsalary.Location = new System.Drawing.Point(67, 152);
            this.btn_getsalary.Name = "btn_getsalary";
            this.btn_getsalary.Size = new System.Drawing.Size(75, 23);
            this.btn_getsalary.TabIndex = 5;
            this.btn_getsalary.Text = "Get Salary";
            this.btn_getsalary.UseVisualStyleBackColor = true;
            this.btn_getsalary.Click += new System.EventHandler(this.btn_getsalary_Click);
            // 
            // lbl_salary
            // 
            this.lbl_salary.AutoSize = true;
            this.lbl_salary.Location = new System.Drawing.Point(187, 157);
            this.lbl_salary.Name = "lbl_salary";
            this.lbl_salary.Size = new System.Drawing.Size(36, 13);
            this.lbl_salary.TabIndex = 6;
            this.lbl_salary.Text = "Salary";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.lbl_salary);
            this.Controls.Add(this.btn_getsalary);
            this.Controls.Add(this.txt_perdaysalary);
            this.Controls.Add(this.txt_days);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_days);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_days;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_days;
        private System.Windows.Forms.TextBox txt_perdaysalary;
        private System.Windows.Forms.Button btn_getsalary;
        private System.Windows.Forms.Label lbl_salary;
    }
}

