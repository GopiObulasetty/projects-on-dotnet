﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Enum_Var_Dynamic_Using
{ 
    enum PaymentType
    {
        COD,Cash,Card,NetBanking
    }
}
