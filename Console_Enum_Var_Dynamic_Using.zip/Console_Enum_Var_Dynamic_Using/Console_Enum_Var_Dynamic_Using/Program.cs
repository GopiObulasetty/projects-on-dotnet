﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using x= Console_Enum_Var_Dynamic_Using;
using static Console_Enum_Var_Dynamic_Using.Test;

namespace Console_Enum_Var_Dynamic_Using
{
    class Program
    {
        static void Main(string[] args)
        {
            x.Test t = new x. Test();
            t.MakePayment(PaymentType.NetBanking);
            call();
        }
    }
}
