﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_hotel
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private string ItemName;
        private int ItemPrice;
        private int ItemQty;
    
        public Order( int orderID,string CustomerName,string ItemName,int ItemPrice,int ItemQty)
        {
            this.OrderID = orderID;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.ItemQty = ItemQty;
           }

        public int GetOrderAmount()
        {
            return this.ItemPrice * this.ItemQty;
        }
    public string GetDetails()
    {
      return this.OrderID+""+this.CustomerName+""+this.ItemName+""+this.ItemPrice+""+this.ItemQty;
          }
    
   
    }

}
