﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_hotel
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the orderID:");
            int OrderID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the Customer name:");
            string CustomerName = Console.ReadLine();
            Console.WriteLine("enter the Item Name:");
            string Itemname = Console.ReadLine();
            Console.WriteLine("enter the Item Price:");
            int ItemPrice= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the Item Qty:");
            int Itemqty = Convert.ToInt32(Console.ReadLine());

            Order obj = new Order(OrderID, CustomerName, Itemname, ItemPrice, Itemqty);

            int Amount = obj.GetOrderAmount();
            Console.WriteLine("Amount:" + Amount);

            string Details = obj.GetDetails();
            Console.WriteLine("Order Details:" + Details);
            Console.ReadLine();







        }
    }
}
