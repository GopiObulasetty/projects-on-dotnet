﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Dictionary_foreach
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> names = new Dictionary<string, string>();
            names.Add("E1", "Ajay");
            names.Add("E2", "vijay");
            names.Add("E3", "gopi");
            names.Add("E4", "ram sandi");
            names.Add("E5", "ram sandi");

            foreach(KeyValuePair<string,string> s in names)
            {
                Console.WriteLine(s.Key + "" + s.Value);
            }

            foreach(string k in names.Keys)
            {
                Console.WriteLine(k);
            }
            foreach(string v in names.Values)
                {
                Console.WriteLine(v);
            }

            string name = names["E1"];
            Console.WriteLine(name);

            Console.ReadLine();


        }
    }
}
