﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;//must to write

namespace Console_Collection
{
    class Program
    {
        static void Main(string[] args)
        {

            /*ArrayList list = new ArrayList();
            list.Add(1000);
            list.Add(2000);
            list.Add(3000);
            int x = 4000;
            list.Add(x);*/
            list.Add("ABC");
            int x1 = Convert.ToInt32(List[0]);
          //  foreach(int m in List)
           // {
           //     Console.WriteLine(m);
          //  }

            Console.WriteLine(list.Count);
            list.Remove(1000);
            list.RemoveAt(0);
            Console.ReadLine();


        }
    }
}
