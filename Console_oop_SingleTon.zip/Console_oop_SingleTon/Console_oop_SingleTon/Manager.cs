﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_SingleTon
{
    class Manager
    {
        private int ManagerID;
        private string MangerName;

        public int PManagerID { get { return this.ManagerID; } }
        public string PManagerName { get { return this.MangerName; } }

        private Manager(int ManagerID, string MangerName)
        {
            this.ManagerID = ManagerID;
            this.MangerName = MangerName;
        }

        static Manager m;
        public static Manager GetManager()
        {
            if (m == null)
            {


                Manager m = new Manager(100, "abc");
                return m;
            }
        }

    }
}
