﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_SingleTon
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager m1 = Manager.GetManager();
            Manager m2 = Manager.GetManager();
            if(m1==m1)
            {
                Console.WriteLine("SingleTon");
            }
            else
            {
                Console.WriteLine("not single ton");
            }
            Console.ReadLine();
        }
    }
}
