﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_student_pratice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_studentname.Text = string.Empty;
            txt_password.Text = string.Empty;
            txt_city.Text = string.Empty;
            txt_address.Text = string.Empty;
            txt_emailid.Text = string.Empty;
        }

        private void btn_newstudent_Click(object sender, EventArgs e)
        {
            if(txt_studentname.Text==string.Empty)
            {
                MessageBox.Show("enter name");
            }
            else if (txt_password.Text == string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else if (txt_city.Text == string.Empty)
            {
                MessageBox.Show("enter cty");
            }
            else if (txt_address.Text == string.Empty)
            {
                MessageBox.Show("address");
            }
            else if (txt_emailid.Text == string.Empty)
            {
                MessageBox.Show("email");
            }
            else
            {
                string name = txt_studentname.Text;
                string password = txt_password.Text;
                string city = txt_city.Text;
                string address = txt_address.Text;
                string email = txt_emailid.Text;

                student obj = new student();
                obj.studentname = name;
                obj.studentpasword = password;
                obj.studentcity = city;
                obj.studentaddres = address;
                obj.studentemailid = email;

                studentDAL dal = new studentDAL();
                int id = dal.addstudent(obj);
                MessageBox.Show("student added"+id);


            }
        }
    }
}
