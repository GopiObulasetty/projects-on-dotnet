﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_student_pratice
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if(txt_emailid.Text==string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int ID = Convert.ToInt32(txt_studentid.Text);
                studentDAL dal = new studentDAL();
                student stu = dal.Find(ID);
                if(stu!=null)
                {
                    txt_studentname.Text = stu.studentname;
                    txt_city.Text = stu.studentcity;
                    txt_address.Text = stu.studentaddres;
                    txt_emailid.Text = stu.studentemailid;
                }
                else
                {
                    MessageBox.Show("not found");
                }
                    



            }

        }
    }
}
