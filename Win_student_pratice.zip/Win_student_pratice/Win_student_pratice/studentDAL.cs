﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Win_student_pratice
{
    class studentDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);

        public int addstudent(student stu)
        {
            SqlCommand com_stu_insert = new SqlCommand("insert tbl_students values(@name,@password,@city,@address,@email)", con);
            com_stu_insert.Parameters.AddWithValue("@name", stu.studentname);
            com_stu_insert.Parameters.AddWithValue("@password", stu.studentpasword);
            com_stu_insert.Parameters.AddWithValue("@city", stu.studentcity);
            com_stu_insert.Parameters.AddWithValue("@address", stu.studentaddres);
            com_stu_insert.Parameters.AddWithValue("@email", stu.studentemailid);

            con.Open();
            com_stu_insert.ExecuteNonQuery();
            SqlCommand com_id = new SqlCommand("select @@identity", con);
            int ID = Convert.ToInt32(com_id.ExecuteScalar());
            con.Close();
            return ID;
        }

        public student Find(int ID)
        {
            SqlCommand com_find = new SqlCommand("select * from tbl_students where studentid=@id", con);
            com_find.Parameters.AddWithValue("@id", ID);
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            con.Close();
            if(dr.Read())
            {
                student stu = new student();
                stu.studentid = dr.GetInt32(0);
                stu.studentname = dr.GetString(1);
                stu.studentpasword = dr.GetString(2);
                stu.studentcity = dr.GetString(3);
                stu.studentaddres = dr.GetString(4);
                stu.studentemailid = dr.GetString(5);
                con.Close();
                return stu;
            }
            else
            {
                return null;
            }

        }


        public bool update(int ID, string password, string city)
        {
            SqlCommand com_update = new SqlCommand("update from tbl_students set studentid=@id,studentpassword=@password,studentcity=@city", con);
            com_update.Parameters.AddWithValue("@id", ID);
            com_update.Parameters.AddWithValue("@password", password);
            com_update.Parameters.AddWithValue("@city", city);
            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand("delete tbl_students where studentid=@id", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            con.Close();
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

    }
}
