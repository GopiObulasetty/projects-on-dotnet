﻿namespace Win_student_pratice
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_studentname = new System.Windows.Forms.Label();
            this.lbl_password = new System.Windows.Forms.Label();
            this.lbl_city = new System.Windows.Forms.Label();
            this.lbl_address = new System.Windows.Forms.Label();
            this.lbl_email = new System.Windows.Forms.Label();
            this.txt_studentname = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.txt_city = new System.Windows.Forms.TextBox();
            this.txt_address = new System.Windows.Forms.TextBox();
            this.txt_emailid = new System.Windows.Forms.TextBox();
            this.btn_newstudent = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_studentname
            // 
            this.lbl_studentname.AutoSize = true;
            this.lbl_studentname.Location = new System.Drawing.Point(38, 38);
            this.lbl_studentname.Name = "lbl_studentname";
            this.lbl_studentname.Size = new System.Drawing.Size(75, 13);
            this.lbl_studentname.TabIndex = 0;
            this.lbl_studentname.Text = "Student Name";
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Location = new System.Drawing.Point(42, 73);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(53, 13);
            this.lbl_password.TabIndex = 1;
            this.lbl_password.Text = "Password";
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Location = new System.Drawing.Point(60, 113);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(24, 13);
            this.lbl_city.TabIndex = 2;
            this.lbl_city.Text = "City";
            // 
            // lbl_address
            // 
            this.lbl_address.AutoSize = true;
            this.lbl_address.Location = new System.Drawing.Point(57, 148);
            this.lbl_address.Name = "lbl_address";
            this.lbl_address.Size = new System.Drawing.Size(45, 13);
            this.lbl_address.TabIndex = 3;
            this.lbl_address.Text = "Address";
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Location = new System.Drawing.Point(57, 181);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(46, 13);
            this.lbl_email.TabIndex = 4;
            this.lbl_email.Text = "Email ID";
            // 
            // txt_studentname
            // 
            this.txt_studentname.Location = new System.Drawing.Point(131, 35);
            this.txt_studentname.Name = "txt_studentname";
            this.txt_studentname.Size = new System.Drawing.Size(137, 20);
            this.txt_studentname.TabIndex = 5;
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(131, 70);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(136, 20);
            this.txt_password.TabIndex = 6;
            // 
            // txt_city
            // 
            this.txt_city.Location = new System.Drawing.Point(130, 108);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(137, 20);
            this.txt_city.TabIndex = 7;
            // 
            // txt_address
            // 
            this.txt_address.Location = new System.Drawing.Point(129, 143);
            this.txt_address.Name = "txt_address";
            this.txt_address.Size = new System.Drawing.Size(138, 20);
            this.txt_address.TabIndex = 8;
            // 
            // txt_emailid
            // 
            this.txt_emailid.Location = new System.Drawing.Point(131, 176);
            this.txt_emailid.Name = "txt_emailid";
            this.txt_emailid.Size = new System.Drawing.Size(135, 20);
            this.txt_emailid.TabIndex = 9;
            // 
            // btn_newstudent
            // 
            this.btn_newstudent.Location = new System.Drawing.Point(90, 256);
            this.btn_newstudent.Name = "btn_newstudent";
            this.btn_newstudent.Size = new System.Drawing.Size(100, 23);
            this.btn_newstudent.TabIndex = 10;
            this.btn_newstudent.Text = "New Student";
            this.btn_newstudent.UseVisualStyleBackColor = true;
            this.btn_newstudent.Click += new System.EventHandler(this.btn_newstudent_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(260, 253);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_reset.TabIndex = 11;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(505, 374);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newstudent);
            this.Controls.Add(this.txt_emailid);
            this.Controls.Add(this.txt_address);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.txt_studentname);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.lbl_address);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.lbl_studentname);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_studentname;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.Label lbl_address;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.TextBox txt_studentname;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.TextBox txt_city;
        private System.Windows.Forms.TextBox txt_address;
        private System.Windows.Forms.TextBox txt_emailid;
        private System.Windows.Forms.Button btn_newstudent;
        private System.Windows.Forms.Button btn_reset;
    }
}

