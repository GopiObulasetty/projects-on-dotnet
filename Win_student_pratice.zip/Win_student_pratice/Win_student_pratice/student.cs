﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_student_pratice
{
    class student
    {
        public int studentid { get; set; }
        public string studentname { get; set; }
        public string studentpasword { get; set; }
        public string studentcity { get; set; }
        public string studentaddres { get; set; }
        public string studentemailid { get; set; }
    }
}
