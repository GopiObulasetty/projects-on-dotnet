﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Console_linq_xml
{
    class Program
    {
        static void Main(string[] args)
        {
            XElement orders = new XElement("Orders",
                new XElement("Order", new XElement("OrderID", "1001"),
                              new XElement("CustomerName", "gopi"),
                              new XElement("OrderAmt", "20000")),

            new XElement("Order", new XElement("OrderID", "1002"),
                              new XElement("CustomerName", "vginay"),
                              new XElement("OrderAmt", "30000"))
                              );
            orders.Save(@"E:/xml/order.xml");
            Console.WriteLine("xml file created");











            /*string url = @"E:\projects\Console_linq_xml\Console_linq_xml\Customers.xml";


            XDocument doc = XDocument.Load(url);

            var data = from x in doc.Descendants("Customer")
                           //  where x.Element("CustomerCity").Value=="BGL"
                       select new
                       {
                           CID = x.Element("CustomerID").Value,
                           CName = x.Element("CustomerName").Value,
                           CCity = x.Element("CustomerCity").Value



                       };

            foreach(var d in data)
                {
                Console.WriteLine(d.CID + " " + d.CName + "  " + d.CCity);
            }*/
            Console.ReadLine();
         }
    }
}
