﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_ManageEmp_Company
{
    class Program
    {
        static void Main(string[] args)
        {
            Company c = new Company("tcs", "bangolore");

            bool flag = true;
            while (flag)
            {
                Console.WriteLine("enter opts:1.add employee,2.find employe,3.remove employee,4.showall,5.Exit,6.leave");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        Console.WriteLine("ente the Emploee name");
                        string Name = Console.ReadLine();
                        Console.WriteLine("enter the employee city");
                        string City = Console.ReadLine();
                        Employee e = new Employee(Name, City);
                        c.AddEmployee(e);
                        Console.WriteLine("student added" + e.PEmployeeID);
                        break;
                    case 2:
                        Console.WriteLine("enter the EmploeeID");
                        int ID = Convert.ToInt32(Console.ReadLine());
                        Employee obj = c.Find(ID);

                        if (obj != null)
                        {
                            Console.WriteLine(obj.PEmployeeID + "" + obj.PEmployeeName);
                        }
                        else
                        {
                            Console.WriteLine("employee not found");
                        }
                        break;
                    case 3:
                        Console.WriteLine("enter the EmployeeID");
                        int SID = Convert.ToInt32(Console.ReadLine());
                        bool status = c.Remove(SID);
                        if (status)
                        {
                            Console.WriteLine("Employee is removed");
                        }
                        else
                        {
                            Console.WriteLine("student not found");
                        }
                        break;
                    case 4:
                        c.ShowAll();
                        break;
                    case 5:
                        flag = false;
                        break;
                    case 6:Console.WriteLine("enter the employeeID");
                        int EmployeeId = Convert.ToInt32(Console.ReadLine());
                }


            }
        }
    }
}

