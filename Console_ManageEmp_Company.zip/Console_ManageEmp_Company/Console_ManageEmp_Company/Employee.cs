﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_ManageEmp_Company
{
    class Employee
    {
        private int EmployeeID;
        private string EmployeeName;
        private string EmployeeCity;
        private static int Count = 1000;

        public int PEmployeeID { get { return this.EmployeeID; } }

        public string PEmployeeName { get { return this.EmployeeName; } }

        public string PEmployeeCity { get { return this.EmployeeCity; } }


        public Employee(string EmployeeName, string EmployeeCity)
        {
            Employee.Count++;
            this.EmployeeID = Employee.Count;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;

        }

        public void TakeLeave(string reason)
        {
            Console.WriteLine("employee on leave" + this.EmployeeID + ",reason" + reason);
        }
    }
}
