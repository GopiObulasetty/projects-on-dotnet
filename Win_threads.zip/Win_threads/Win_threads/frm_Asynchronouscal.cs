﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Win_threads
{
    public partial class frm_Asynchronouscal : Form
    {
        public delegate int delthread(int n1, int n2);
        public int GetSum(int n1,int n2)
        {
            Thread.Sleep(500);
            return n1 + n2;
        }
        public delegate void del();
        public void callback(IAsyncResult res)
        {
            int retdata = d.EndInvoke(res);
            // MessageBox.Show("getSum called"+res.AsyncState+":"+retdata);
            del obj = new del(() =>
            { 
            lst_msg.Items.Add( res.AsyncState + ":" + retdata);
            });
            this.BeginInvoke(obj);//main thread
        }


        public frm_Asynchronouscal()
        {
            InitializeComponent();
        }
        delthread d;
        private void btn_asynchoronous_Click(object sender, EventArgs e)
        {
            if (d == null)
            {
                d= new delthread(this.GetSum);

            }
            int n1 = Convert.ToInt32(txt_number1.Text);
            int n2 = Convert.ToInt32(txt_number2.Text);

            string str = n1 + "+" + n2; //new thread

            d.BeginInvoke(n1, n2, callback, str);//new thread
           // d.BeginInvoke(n1, n2, callback, "1002");//new thread

        }
    }
}
