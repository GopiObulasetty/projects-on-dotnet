﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Win_threads
{
    public partial class win_ThreadPool : Form
    {

        public void call(object obj)
        {
            int id = Thread.CurrentThread.ManagedThreadId;
            MessageBox.Show("Thread ID" + id + ",loop no" + obj);
        }

        public win_ThreadPool()
        {
            InitializeComponent();
        }

        private void btn_threadpool_Click(object sender, EventArgs e)
        {
            ThreadPool.SetMaxThreads(10, 1000);
            ThreadPool.SetMinThreads(5, 1000);

            int counter = 0;
            while(counter<20)
            {
                ThreadPool.QueueUserWorkItem(call, counter);
                counter++;
            }
            MessageBox.Show("Main thread");
        }
    }
}
