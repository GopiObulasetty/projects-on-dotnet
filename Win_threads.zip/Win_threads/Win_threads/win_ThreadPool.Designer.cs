﻿namespace Win_threads
{
    partial class win_ThreadPool
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_threadpool = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_threadpool
            // 
            this.btn_threadpool.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_threadpool.Location = new System.Drawing.Point(119, 157);
            this.btn_threadpool.Name = "btn_threadpool";
            this.btn_threadpool.Size = new System.Drawing.Size(166, 49);
            this.btn_threadpool.TabIndex = 0;
            this.btn_threadpool.Text = "ThreadPool";
            this.btn_threadpool.UseVisualStyleBackColor = true;
            this.btn_threadpool.Click += new System.EventHandler(this.btn_threadpool_Click);
            // 
            // win_ThreadPool
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 317);
            this.Controls.Add(this.btn_threadpool);
            this.Name = "win_ThreadPool";
            this.Text = "win_ThreadPool";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_threadpool;
    }
}