﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
namespace Win_threads
{
    public partial class Form2 : Form
    {

        ReaderWriterLock rw = new ReaderWriterLock();

        int total;


        public void sum()
        {
            int n1 = Convert.ToInt32(txt_number1.Text);
            int n2 = Convert.ToInt32(txt_number2.Text);
            rw.AcquireReaderLock(Timeout.Infinite);
           // if (Monitor.TryEnter(this,3000))

             //   if (Monitor.TryEnter(this))
            //{ 

           // Monitor.Enter(this);

          //  lock(this)
           // { 
            total = n1 + n2;
            Thread.Sleep(15000);
            MessageBox.Show("total" + total);
            rw.ReleaseLock();

            // }
            //  Monitor.Exit(this);
            // }
            // else
            //  {
            //     MessageBox.Show("other task");
            // }
        }

        public void sum2()
        {
            int n1 = Convert.ToInt32(txt_number1.Text);
            int n2 = Convert.ToInt32(txt_number2.Text);
            rw.AcquireWriterLock(Timeout.Infinite);



            total = n1 + n2;
            Thread.Sleep(15000);
            MessageBox.Show("total" + total);
            rw.ReleaseLock();
        }






        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btn_thread1_Click(object sender, EventArgs e)
        {
            Thread th1 = new Thread(this.sum);
            th1.Start();
            
        }

        private void btn_thread2_Click(object sender, EventArgs e)
        {
            Thread th2 = new Thread(this.sum);
            th2.Start();

        }
    }
}
