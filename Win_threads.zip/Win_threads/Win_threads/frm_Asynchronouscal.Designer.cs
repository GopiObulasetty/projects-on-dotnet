﻿namespace Win_threads
{
    partial class frm_Asynchronouscal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_number2 = new System.Windows.Forms.TextBox();
            this.txt_number1 = new System.Windows.Forms.TextBox();
            this.lbl_number2 = new System.Windows.Forms.Label();
            this.lbl_number1 = new System.Windows.Forms.Label();
            this.btn_asynchoronous = new System.Windows.Forms.Button();
            this.lst_msg = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // txt_number2
            // 
            this.txt_number2.Location = new System.Drawing.Point(239, 169);
            this.txt_number2.Name = "txt_number2";
            this.txt_number2.Size = new System.Drawing.Size(100, 20);
            this.txt_number2.TabIndex = 11;
            // 
            // txt_number1
            // 
            this.txt_number1.Location = new System.Drawing.Point(237, 112);
            this.txt_number1.Name = "txt_number1";
            this.txt_number1.Size = new System.Drawing.Size(100, 20);
            this.txt_number1.TabIndex = 10;
            // 
            // lbl_number2
            // 
            this.lbl_number2.AutoSize = true;
            this.lbl_number2.Location = new System.Drawing.Point(139, 167);
            this.lbl_number2.Name = "lbl_number2";
            this.lbl_number2.Size = new System.Drawing.Size(53, 13);
            this.lbl_number2.TabIndex = 9;
            this.lbl_number2.Text = "Number 2";
            // 
            // lbl_number1
            // 
            this.lbl_number1.AutoSize = true;
            this.lbl_number1.Location = new System.Drawing.Point(135, 120);
            this.lbl_number1.Name = "lbl_number1";
            this.lbl_number1.Size = new System.Drawing.Size(53, 13);
            this.lbl_number1.TabIndex = 8;
            this.lbl_number1.Text = "Number 1";
            // 
            // btn_asynchoronous
            // 
            this.btn_asynchoronous.Location = new System.Drawing.Point(179, 252);
            this.btn_asynchoronous.Name = "btn_asynchoronous";
            this.btn_asynchoronous.Size = new System.Drawing.Size(75, 23);
            this.btn_asynchoronous.TabIndex = 6;
            this.btn_asynchoronous.Text = "Asynch Sum";
            this.btn_asynchoronous.UseVisualStyleBackColor = true;
            this.btn_asynchoronous.Click += new System.EventHandler(this.btn_asynchoronous_Click);
            // 
            // lst_msg
            // 
            this.lst_msg.FormattingEnabled = true;
            this.lst_msg.Location = new System.Drawing.Point(305, 226);
            this.lst_msg.Name = "lst_msg";
            this.lst_msg.Size = new System.Drawing.Size(160, 95);
            this.lst_msg.TabIndex = 12;
            // 
            // frm_Asynchronouscal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(551, 386);
            this.Controls.Add(this.lst_msg);
            this.Controls.Add(this.txt_number2);
            this.Controls.Add(this.txt_number1);
            this.Controls.Add(this.lbl_number2);
            this.Controls.Add(this.lbl_number1);
            this.Controls.Add(this.btn_asynchoronous);
            this.Name = "frm_Asynchronouscal";
            this.Text = "frm_Asynchronouscal";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_number2;
        private System.Windows.Forms.TextBox txt_number1;
        private System.Windows.Forms.Label lbl_number2;
        private System.Windows.Forms.Label lbl_number1;
        private System.Windows.Forms.Button btn_asynchoronous;
        private System.Windows.Forms.ListBox lst_msg;
    }
}