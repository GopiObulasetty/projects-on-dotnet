﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_threads
{
    public partial class frm_tasks : Form
    {
        public frm_tasks()
        {
            InitializeComponent();
        }

        private void btn_task_Click(object sender, EventArgs e)
        {
            Task t1 = Task.Run(() =>
              {

                  MessageBox.Show("task1");
              });

            Task t2 =  Task.Run(() =>
              {
                  MessageBox.Show("task 2");
              });
        }

        private async void btn_newtask2_Click(object sender, EventArgs e)
        {
            Test obj = new Test();
            var t=obj.AddNumbersAsync(10, 20);

            MessageBox.Show("some other work");
            int x = await t;
            MessageBox.Show("return Data" + x);

        }
    }
}
