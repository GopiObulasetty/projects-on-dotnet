﻿namespace Win_threads
{
    partial class frm_tasks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_task = new System.Windows.Forms.Button();
            this.btn_newtask2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_task
            // 
            this.btn_task.Location = new System.Drawing.Point(215, 152);
            this.btn_task.Name = "btn_task";
            this.btn_task.Size = new System.Drawing.Size(75, 23);
            this.btn_task.TabIndex = 0;
            this.btn_task.Text = "New Task";
            this.btn_task.UseVisualStyleBackColor = true;
            this.btn_task.Click += new System.EventHandler(this.btn_task_Click);
            // 
            // btn_newtask2
            // 
            this.btn_newtask2.Location = new System.Drawing.Point(215, 221);
            this.btn_newtask2.Name = "btn_newtask2";
            this.btn_newtask2.Size = new System.Drawing.Size(75, 23);
            this.btn_newtask2.TabIndex = 1;
            this.btn_newtask2.Text = "New Task2";
            this.btn_newtask2.UseVisualStyleBackColor = true;
            this.btn_newtask2.Click += new System.EventHandler(this.btn_newtask2_Click);
            // 
            // frm_tasks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 348);
            this.Controls.Add(this.btn_newtask2);
            this.Controls.Add(this.btn_task);
            this.Name = "frm_tasks";
            this.Text = "frm_tasks";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_task;
        private System.Windows.Forms.Button btn_newtask2;
    }
}