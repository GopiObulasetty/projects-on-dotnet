﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            try
            {
                int ID = Convert.ToInt32(txt_employeeid.Text);
            string password = txt_password.Text;
            
                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Login(ID, password);
                if (status)
                {
                    MessageBox.Show("valid user");
                    //frm_home home=  new frm_home()
                }
                else
                {
                    MessageBox.Show("inavalid user");
                }
            }
            catch (System.Data.SqlClient.SqlException exp)
            {
                MessageBox.Show("sql error");
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
            finally
            {
                MessageBox.Show("finnally block");
            }
            MessageBox.Show("after finally");
        }
            

        private void btn_sqlinjection_Click(object sender, EventArgs e)
        {
            string id = txt_employeeid.Text;
            string password = txt_password.Text;

            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.LoginsqlInjection(id,password);
            if(status)
            {
                MessageBox.Show("valid user");
            }
            else
            {
                MessageBox.Show("invalid user");
            }


        }
         
           


         

    }
}
