﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class frm_Find : Form
    {
        public frm_Find()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_employeeid.Text == string.Empty)
            {
                MessageBox.Show("enter ID");
            }
            else
            {
                int ID = Convert.ToInt32(txt_employeeid.Text);
                EmployeeDAL dal = new EmployeeDAL();
                employee emp = dal.Find(ID);
                if (emp != null)
                {
                    txt_employeename.Text = emp.employeename;
                    txt_employepassword.Text = emp.employeepassword;
                    txt_employeecity.Text = emp.employeecity;
                    txt_employeedoj.Text = emp.employeeDOJ.ToString();

                }
                else
                {
                    MessageBox.Show("not found");
                }











            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txt_employeeid.Text == string.Empty)
            {
                MessageBox.Show("enter ID");
            }
            else if (txt_employeecity.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if (txt_employepassword.Text == string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else {
                int ID = Convert.ToInt32(txt_employeeid.Text);
                string city = txt_employeecity.Text;
                string password = txt_employepassword.Text;

                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Update(ID, city, password);
                if(status)
                {
                    MessageBox.Show("update");
                }
                else
                {
                    MessageBox.Show("not found");
                }
                    

        }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if(txt_employeeid.Text==string.Empty)
            {
                MessageBox.Show("enter ID");
            }
            else if (txt_employeecity.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if (txt_employepassword.Text == string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {
                int ID = Convert.ToInt32(txt_employeeid.Text);
                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Delete(ID);
                if(status)
                {
                    MessageBox.Show("deleted");
                }
                else
                {
                    MessageBox.Show("not found");
                }
            }
        }
    }
}