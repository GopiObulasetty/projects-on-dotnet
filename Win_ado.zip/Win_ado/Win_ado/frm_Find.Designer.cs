﻿namespace Win_ado
{
    partial class frm_Find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_employeepassword = new System.Windows.Forms.Label();
            this.txt_employepassword = new System.Windows.Forms.TextBox();
            this.txt_employeecity = new System.Windows.Forms.TextBox();
            this.lbl_employeecity = new System.Windows.Forms.Label();
            this.txt_employeename = new System.Windows.Forms.TextBox();
            this.lbl_employeename = new System.Windows.Forms.Label();
            this.btn_find = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.lbl_employeeid = new System.Windows.Forms.Label();
            this.txt_employeeid = new System.Windows.Forms.TextBox();
            this.txt_employeedoj = new System.Windows.Forms.TextBox();
            this.lbl_employeedoj = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_employeepassword
            // 
            this.lbl_employeepassword.AutoSize = true;
            this.lbl_employeepassword.Location = new System.Drawing.Point(164, 171);
            this.lbl_employeepassword.Name = "lbl_employeepassword";
            this.lbl_employeepassword.Size = new System.Drawing.Size(102, 13);
            this.lbl_employeepassword.TabIndex = 13;
            this.lbl_employeepassword.Text = "Employee Password";
            // 
            // txt_employepassword
            // 
            this.txt_employepassword.Location = new System.Drawing.Point(289, 171);
            this.txt_employepassword.Name = "txt_employepassword";
            this.txt_employepassword.Size = new System.Drawing.Size(146, 20);
            this.txt_employepassword.TabIndex = 12;
            // 
            // txt_employeecity
            // 
            this.txt_employeecity.Location = new System.Drawing.Point(289, 120);
            this.txt_employeecity.Name = "txt_employeecity";
            this.txt_employeecity.Size = new System.Drawing.Size(147, 20);
            this.txt_employeecity.TabIndex = 11;
            // 
            // lbl_employeecity
            // 
            this.lbl_employeecity.AutoSize = true;
            this.lbl_employeecity.Location = new System.Drawing.Point(164, 123);
            this.lbl_employeecity.Name = "lbl_employeecity";
            this.lbl_employeecity.Size = new System.Drawing.Size(73, 13);
            this.lbl_employeecity.TabIndex = 10;
            this.lbl_employeecity.Text = "Employee City";
            // 
            // txt_employeename
            // 
            this.txt_employeename.Location = new System.Drawing.Point(289, 78);
            this.txt_employeename.Name = "txt_employeename";
            this.txt_employeename.Size = new System.Drawing.Size(147, 20);
            this.txt_employeename.TabIndex = 9;
            // 
            // lbl_employeename
            // 
            this.lbl_employeename.AutoSize = true;
            this.lbl_employeename.Location = new System.Drawing.Point(164, 78);
            this.lbl_employeename.Name = "lbl_employeename";
            this.lbl_employeename.Size = new System.Drawing.Size(84, 13);
            this.lbl_employeename.TabIndex = 8;
            this.lbl_employeename.Text = "Employee Name";
            // 
            // btn_find
            // 
            this.btn_find.Location = new System.Drawing.Point(551, 35);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(75, 23);
            this.btn_find.TabIndex = 16;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // btn_update
            // 
            this.btn_update.Location = new System.Drawing.Point(551, 100);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(75, 23);
            this.btn_update.TabIndex = 17;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(551, 166);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 18;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // lbl_employeeid
            // 
            this.lbl_employeeid.AutoSize = true;
            this.lbl_employeeid.Location = new System.Drawing.Point(164, 35);
            this.lbl_employeeid.Name = "lbl_employeeid";
            this.lbl_employeeid.Size = new System.Drawing.Size(67, 13);
            this.lbl_employeeid.TabIndex = 19;
            this.lbl_employeeid.Text = "Employee ID";
            // 
            // txt_employeeid
            // 
            this.txt_employeeid.Location = new System.Drawing.Point(289, 35);
            this.txt_employeeid.Name = "txt_employeeid";
            this.txt_employeeid.Size = new System.Drawing.Size(146, 20);
            this.txt_employeeid.TabIndex = 20;
            // 
            // txt_employeedoj
            // 
            this.txt_employeedoj.Location = new System.Drawing.Point(289, 215);
            this.txt_employeedoj.Name = "txt_employeedoj";
            this.txt_employeedoj.Size = new System.Drawing.Size(147, 20);
            this.txt_employeedoj.TabIndex = 21;
            // 
            // lbl_employeedoj
            // 
            this.lbl_employeedoj.AutoSize = true;
            this.lbl_employeedoj.Location = new System.Drawing.Point(164, 218);
            this.lbl_employeedoj.Name = "lbl_employeedoj";
            this.lbl_employeedoj.Size = new System.Drawing.Size(77, 13);
            this.lbl_employeedoj.TabIndex = 22;
            this.lbl_employeedoj.Text = "Employee DOJ";
            // 
            // frm_Find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(823, 467);
            this.Controls.Add(this.lbl_employeedoj);
            this.Controls.Add(this.txt_employeedoj);
            this.Controls.Add(this.txt_employeeid);
            this.Controls.Add(this.lbl_employeeid);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.lbl_employeepassword);
            this.Controls.Add(this.txt_employepassword);
            this.Controls.Add(this.txt_employeecity);
            this.Controls.Add(this.lbl_employeecity);
            this.Controls.Add(this.txt_employeename);
            this.Controls.Add(this.lbl_employeename);
            this.Name = "frm_Find";
            this.Text = "frm_Find";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_employeepassword;
        private System.Windows.Forms.TextBox txt_employepassword;
        private System.Windows.Forms.TextBox txt_employeecity;
        private System.Windows.Forms.Label lbl_employeecity;
        private System.Windows.Forms.TextBox txt_employeename;
        private System.Windows.Forms.Label lbl_employeename;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Label lbl_employeeid;
        private System.Windows.Forms.TextBox txt_employeeid;
        private System.Windows.Forms.TextBox txt_employeedoj;
        private System.Windows.Forms.Label lbl_employeedoj;
    }
}