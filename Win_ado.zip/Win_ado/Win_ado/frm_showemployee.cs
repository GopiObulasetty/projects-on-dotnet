﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class frm_showemployee : Form
    {
        public frm_showemployee()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            EmployeeDAL dal = new EmployeeDAL();
            string city = txt_employeecity.Text;
            List<employee> list = dal.ShowEmployees(city);
            dg_employees.DataSource = list;
        }

        private void btn_Searchall_Click(object sender, EventArgs e)
        {
            EmployeeDAL dal = new EmployeeDAL();
            string key = txt_search.Text;
            List<employee> list = dal.SearchEmployee(key);
            dg_employees.DataSource = list;
        }
    }
}
