﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_employeename.Text = string.Empty;
            txt_employeecity.Text = string.Empty;
            txt_employepassword.Text = string.Empty;
        }

        private void btn_newemployee_Click(object sender, EventArgs e)
        {
            if(txt_employeename.Text==string.Empty)
            {
                MessageBox.Show("Enter name");
            }
            else if(txt_employeecity.Text==string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if(txt_employepassword.Text==string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {
                string name = txt_employeename.Text;
                string city = txt_employeecity.Text;
                string password = txt_employepassword.Text;

                employee obj = new employee();
                obj.employeename = name;
                obj.employeecity = city;
                obj.employeepassword = password;

                EmployeeDAL dal = new EmployeeDAL();
                int id = dal.AddEmployee(obj);
                MessageBox.Show("Employee added" + id);






            }
        }
    }
}
