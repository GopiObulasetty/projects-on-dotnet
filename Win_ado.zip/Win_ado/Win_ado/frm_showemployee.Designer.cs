﻿namespace Win_ado
{
    partial class frm_showemployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_employeecity = new System.Windows.Forms.Label();
            this.lbl_search = new System.Windows.Forms.Label();
            this.txt_employeecity = new System.Windows.Forms.TextBox();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.btn_find = new System.Windows.Forms.Button();
            this.btn_Searchall = new System.Windows.Forms.Button();
            this.dg_employees = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_employees)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_employeecity
            // 
            this.lbl_employeecity.AutoSize = true;
            this.lbl_employeecity.Location = new System.Drawing.Point(70, 44);
            this.lbl_employeecity.Name = "lbl_employeecity";
            this.lbl_employeecity.Size = new System.Drawing.Size(101, 13);
            this.lbl_employeecity.TabIndex = 0;
            this.lbl_employeecity.Text = "Enter Employee City";
            // 
            // lbl_search
            // 
            this.lbl_search.AutoSize = true;
            this.lbl_search.Location = new System.Drawing.Point(67, 94);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(41, 13);
            this.lbl_search.TabIndex = 1;
            this.lbl_search.Text = "Search";
            this.lbl_search.Click += new System.EventHandler(this.label1_Click);
            // 
            // txt_employeecity
            // 
            this.txt_employeecity.Location = new System.Drawing.Point(196, 37);
            this.txt_employeecity.Name = "txt_employeecity";
            this.txt_employeecity.Size = new System.Drawing.Size(138, 20);
            this.txt_employeecity.TabIndex = 2;
            // 
            // txt_search
            // 
            this.txt_search.Location = new System.Drawing.Point(196, 85);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(138, 20);
            this.txt_search.TabIndex = 3;
            this.txt_search.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // btn_find
            // 
            this.btn_find.Location = new System.Drawing.Point(424, 44);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(75, 23);
            this.btn_find.TabIndex = 4;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // btn_Searchall
            // 
            this.btn_Searchall.Location = new System.Drawing.Point(424, 94);
            this.btn_Searchall.Name = "btn_Searchall";
            this.btn_Searchall.Size = new System.Drawing.Size(75, 23);
            this.btn_Searchall.TabIndex = 5;
            this.btn_Searchall.Text = "Search(All)";
            this.btn_Searchall.UseVisualStyleBackColor = true;
            this.btn_Searchall.Click += new System.EventHandler(this.btn_Searchall_Click);
            // 
            // dg_employees
            // 
            this.dg_employees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_employees.Location = new System.Drawing.Point(44, 140);
            this.dg_employees.Name = "dg_employees";
            this.dg_employees.Size = new System.Drawing.Size(526, 209);
            this.dg_employees.TabIndex = 6;
            // 
            // frm_showemployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(646, 361);
            this.Controls.Add(this.dg_employees);
            this.Controls.Add(this.btn_Searchall);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.txt_employeecity);
            this.Controls.Add(this.lbl_search);
            this.Controls.Add(this.lbl_employeecity);
            this.Name = "frm_showemployee";
            this.Text = "frm_showemployee";
            ((System.ComponentModel.ISupportInitialize)(this.dg_employees)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_employeecity;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.TextBox txt_employeecity;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_Searchall;
        private System.Windows.Forms.DataGridView dg_employees;
    }
}