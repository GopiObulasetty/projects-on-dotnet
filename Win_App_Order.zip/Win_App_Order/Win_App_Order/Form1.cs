﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_App_Order
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmb_ordercity.Items.Add("tenali");
            cmb_ordercity.Items.Add("guntur");
            cmb_ordercity.Items.Add("vijwd");



        }

        private void btn_placeorder_Click(object sender, EventArgs e)
        {
            if (txt_orderid.Text == string.Empty)
            {
                MessageBox.Show("enter the order id");
            }
            else if (txt_customername.Text == string.Empty)
            {
                MessageBox.Show("enter the custemer name");
            }
            else if (txt_itemid.Text == string.Empty)
            {
                MessageBox.Show("enter the item id");
            }
            else if (txt_itemqty.Text == string.Empty)
            {
                MessageBox.Show("enter the itemqty");
            }
            else if (txt_deliveradress.Text == string.Empty)
            {
                MessageBox.Show("enter the delivery address");
            }
            else
            {
                int orderid =Convert.ToInt32(txt_orderid.Text);
                string custumername = txt_customername.Text;
                int itemid = Convert.ToInt32(txt_itemid.Text);
                int itemqty= Convert.ToInt32(txt_itemqty.Text);
                int price= Convert.ToInt32(txt_itemprice.Text);
                string deliveryAddress = txt_deliveradress.Text;
                string city = cmb_ordercity.Text;

                string payment = string.Empty;
                if (rdb_online.Checked)
                {
                    payment = "online";
                }
                else
                {
                    payment = "cash on delivery";
                }



                Order obj = new Order(orderid, custumername, itemid, itemqty,price, deliveryAddress, city, payment);
                int ordervalue =obj. GetOrderValue();
                MessageBox.Show("order vale" + ordervalue);
                    }



        }
    }
}