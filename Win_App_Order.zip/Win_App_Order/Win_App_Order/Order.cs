﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_App_Order
{
    class Order
    {
       private int OrderID;
       private string CustomerName;
       private int ItemID;
        private int ItemQty;
        private int ItemPrice;
        private string DeliveryAddress;
        private string OrderCity;
        private string PaymentOption;
        
        
        public Order(int OrderID, string CustomerName, int ItemID, int ItemQty, int ItemPrice,
            string DeliveryAddress, string OrderCity, string PaymentOption)
        {
            this.OrderID = OrderID;
            this.CustomerName = CustomerName;
            this.ItemID = ItemID;
            this.ItemQty = ItemQty;
            this.DeliveryAddress = DeliveryAddress;
            this.OrderCity = OrderCity;
            this.ItemPrice = ItemPrice;
            this.PaymentOption = PaymentOption;
         }
        public int GetOrderValue()
        {
            return this.ItemQty * this.ItemPrice;
        }
         
        
         
    }
}
