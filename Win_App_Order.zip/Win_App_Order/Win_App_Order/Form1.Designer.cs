﻿namespace Win_App_Order
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_orderid = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_itemid = new System.Windows.Forms.Label();
            this.txt_orderid = new System.Windows.Forms.TextBox();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.txt_itemid = new System.Windows.Forms.TextBox();
            this.lbl_deliveryaddress = new System.Windows.Forms.Label();
            this.txt_deliveradress = new System.Windows.Forms.TextBox();
            this.lbl_itemprice = new System.Windows.Forms.Label();
            this.txt_itemprice = new System.Windows.Forms.TextBox();
            this.lbl_itemqty = new System.Windows.Forms.Label();
            this.txt_itemqty = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_ordercity = new System.Windows.Forms.Label();
            this.cmb_ordercity = new System.Windows.Forms.ComboBox();
            this.lbl_paymentoption = new System.Windows.Forms.Label();
            this.rdb_online = new System.Windows.Forms.RadioButton();
            this.rdb_cashondelivery = new System.Windows.Forms.RadioButton();
            this.btn_placeorder = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_orderid
            // 
            this.lbl_orderid.AutoSize = true;
            this.lbl_orderid.Location = new System.Drawing.Point(50, 32);
            this.lbl_orderid.Name = "lbl_orderid";
            this.lbl_orderid.Size = new System.Drawing.Size(47, 13);
            this.lbl_orderid.TabIndex = 0;
            this.lbl_orderid.Text = "Order ID";
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Location = new System.Drawing.Point(50, 68);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(82, 13);
            this.lbl_customername.TabIndex = 1;
            this.lbl_customername.Text = "Customer Name";
            // 
            // lbl_itemid
            // 
            this.lbl_itemid.AutoSize = true;
            this.lbl_itemid.Location = new System.Drawing.Point(50, 107);
            this.lbl_itemid.Name = "lbl_itemid";
            this.lbl_itemid.Size = new System.Drawing.Size(41, 13);
            this.lbl_itemid.TabIndex = 2;
            this.lbl_itemid.Text = "Item ID";
            // 
            // txt_orderid
            // 
            this.txt_orderid.Location = new System.Drawing.Point(173, 32);
            this.txt_orderid.Name = "txt_orderid";
            this.txt_orderid.Size = new System.Drawing.Size(194, 20);
            this.txt_orderid.TabIndex = 3;
            // 
            // txt_customername
            // 
            this.txt_customername.Location = new System.Drawing.Point(173, 61);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(194, 20);
            this.txt_customername.TabIndex = 4;
            // 
            // txt_itemid
            // 
            this.txt_itemid.Location = new System.Drawing.Point(173, 100);
            this.txt_itemid.Name = "txt_itemid";
            this.txt_itemid.Size = new System.Drawing.Size(194, 20);
            this.txt_itemid.TabIndex = 5;
            // 
            // lbl_deliveryaddress
            // 
            this.lbl_deliveryaddress.AutoSize = true;
            this.lbl_deliveryaddress.Location = new System.Drawing.Point(50, 184);
            this.lbl_deliveryaddress.Name = "lbl_deliveryaddress";
            this.lbl_deliveryaddress.Size = new System.Drawing.Size(80, 13);
            this.lbl_deliveryaddress.TabIndex = 6;
            this.lbl_deliveryaddress.Text = "Delivery Adress";
            // 
            // txt_deliveradress
            // 
            this.txt_deliveradress.Location = new System.Drawing.Point(173, 177);
            this.txt_deliveradress.Name = "txt_deliveradress";
            this.txt_deliveradress.Size = new System.Drawing.Size(194, 20);
            this.txt_deliveradress.TabIndex = 7;
            // 
            // lbl_itemprice
            // 
            this.lbl_itemprice.AutoSize = true;
            this.lbl_itemprice.Location = new System.Drawing.Point(385, 147);
            this.lbl_itemprice.Name = "lbl_itemprice";
            this.lbl_itemprice.Size = new System.Drawing.Size(53, 13);
            this.lbl_itemprice.TabIndex = 8;
            this.lbl_itemprice.Text = "Item price";
            // 
            // txt_itemprice
            // 
            this.txt_itemprice.Location = new System.Drawing.Point(479, 140);
            this.txt_itemprice.Name = "txt_itemprice";
            this.txt_itemprice.Size = new System.Drawing.Size(121, 20);
            this.txt_itemprice.TabIndex = 9;
            // 
            // lbl_itemqty
            // 
            this.lbl_itemqty.AutoSize = true;
            this.lbl_itemqty.Location = new System.Drawing.Point(50, 147);
            this.lbl_itemqty.Name = "lbl_itemqty";
            this.lbl_itemqty.Size = new System.Drawing.Size(43, 13);
            this.lbl_itemqty.TabIndex = 10;
            this.lbl_itemqty.Text = "ItemQty";
            // 
            // txt_itemqty
            // 
            this.txt_itemqty.Location = new System.Drawing.Point(173, 140);
            this.txt_itemqty.Name = "txt_itemqty";
            this.txt_itemqty.Size = new System.Drawing.Size(194, 20);
            this.txt_itemqty.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "label1";
            // 
            // lbl_ordercity
            // 
            this.lbl_ordercity.AutoSize = true;
            this.lbl_ordercity.Location = new System.Drawing.Point(392, 182);
            this.lbl_ordercity.Name = "lbl_ordercity";
            this.lbl_ordercity.Size = new System.Drawing.Size(53, 13);
            this.lbl_ordercity.TabIndex = 13;
            this.lbl_ordercity.Text = "Order City";
            // 
            // cmb_ordercity
            // 
            this.cmb_ordercity.FormattingEnabled = true;
            this.cmb_ordercity.Location = new System.Drawing.Point(479, 175);
            this.cmb_ordercity.Name = "cmb_ordercity";
            this.cmb_ordercity.Size = new System.Drawing.Size(121, 21);
            this.cmb_ordercity.TabIndex = 14;
            // 
            // lbl_paymentoption
            // 
            this.lbl_paymentoption.AutoSize = true;
            this.lbl_paymentoption.Location = new System.Drawing.Point(50, 224);
            this.lbl_paymentoption.Name = "lbl_paymentoption";
            this.lbl_paymentoption.Size = new System.Drawing.Size(82, 13);
            this.lbl_paymentoption.TabIndex = 15;
            this.lbl_paymentoption.Text = "Payment Option";
            // 
            // rdb_online
            // 
            this.rdb_online.AutoSize = true;
            this.rdb_online.Location = new System.Drawing.Point(177, 223);
            this.rdb_online.Name = "rdb_online";
            this.rdb_online.Size = new System.Drawing.Size(55, 17);
            this.rdb_online.TabIndex = 16;
            this.rdb_online.TabStop = true;
            this.rdb_online.Text = "Online";
            this.rdb_online.UseVisualStyleBackColor = true;
            // 
            // rdb_cashondelivery
            // 
            this.rdb_cashondelivery.AutoSize = true;
            this.rdb_cashondelivery.Location = new System.Drawing.Point(264, 224);
            this.rdb_cashondelivery.Name = "rdb_cashondelivery";
            this.rdb_cashondelivery.Size = new System.Drawing.Size(103, 17);
            this.rdb_cashondelivery.TabIndex = 17;
            this.rdb_cashondelivery.TabStop = true;
            this.rdb_cashondelivery.Text = "Cash on delivery";
            this.rdb_cashondelivery.UseVisualStyleBackColor = true;
            // 
            // btn_placeorder
            // 
            this.btn_placeorder.Location = new System.Drawing.Point(170, 279);
            this.btn_placeorder.Name = "btn_placeorder";
            this.btn_placeorder.Size = new System.Drawing.Size(75, 23);
            this.btn_placeorder.TabIndex = 18;
            this.btn_placeorder.Text = "Place Order";
            this.btn_placeorder.UseVisualStyleBackColor = true;
            this.btn_placeorder.Click += new System.EventHandler(this.btn_placeorder_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 530);
            this.Controls.Add(this.btn_placeorder);
            this.Controls.Add(this.rdb_cashondelivery);
            this.Controls.Add(this.rdb_online);
            this.Controls.Add(this.lbl_paymentoption);
            this.Controls.Add(this.cmb_ordercity);
            this.Controls.Add(this.lbl_ordercity);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_itemqty);
            this.Controls.Add(this.lbl_itemqty);
            this.Controls.Add(this.txt_itemprice);
            this.Controls.Add(this.lbl_itemprice);
            this.Controls.Add(this.txt_deliveradress);
            this.Controls.Add(this.lbl_deliveryaddress);
            this.Controls.Add(this.txt_itemid);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.txt_orderid);
            this.Controls.Add(this.lbl_itemid);
            this.Controls.Add(this.lbl_customername);
            this.Controls.Add(this.lbl_orderid);
            this.Name = "Form1";
            this.Text = "l";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_orderid;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_itemid;
        private System.Windows.Forms.TextBox txt_orderid;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.TextBox txt_itemid;
        private System.Windows.Forms.Label lbl_deliveryaddress;
        private System.Windows.Forms.TextBox txt_deliveradress;
        private System.Windows.Forms.Label lbl_itemprice;
        private System.Windows.Forms.TextBox txt_itemprice;
        private System.Windows.Forms.Label lbl_itemqty;
        private System.Windows.Forms.TextBox txt_itemqty;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_ordercity;
        private System.Windows.Forms.ComboBox cmb_ordercity;
        private System.Windows.Forms.Label lbl_paymentoption;
        private System.Windows.Forms.RadioButton rdb_online;
        private System.Windows.Forms.RadioButton rdb_cashondelivery;
        private System.Windows.Forms.Button btn_placeorder;
    }
}

